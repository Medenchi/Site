import { Box, Candidate, clampBox } from "./geometry";
import { buildPlan, SpinPlan } from "./roulette";
import { Tracker } from "./tracker";
import type { GameEvent, HistoryEntry, PInfo, Phase, RModel, Snapshot } from "./types";

/**
 * Центральное состояние игры: трекер участников, рулетка, история.
 * Живёт вне React — рендер идёт через requestAnimationFrame, а интерфейс
 * получает редкие снимки через useSyncExternalStore.
 */
export class Game {
  tracker = new Tracker();
  phase: Phase = "idle";
  highlightId: number | null = null;
  winnerId: number | null = null;
  selectedId: number | null = null;
  history: HistoryEntry[] = [];
  round = 1;
  excludeWinners = true;
  durationMs = 8000;
  mirror = true;
  draft: Box | null = null;
  onEvent?: (e: GameEvent) => void;

  private plan: SpinPlan | null = null;
  private startAt = 0;
  private stepIdx = -1;
  private tensionSent = false;
  private listeners = new Set<() => void>();
  private version = 0;
  private snap: Snapshot;
  private sig = "";
  private lastSigCheck = 0;

  constructor() {
    this.snap = this.buildSnapshot();
  }

  // ---------- подписка для React ----------
  subscribe = (fn: () => void) => {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  };
  getSnapshot = () => this.snap;

  emit() {
    this.version++;
    this.snap = this.buildSnapshot();
    this.listeners.forEach((l) => l());
  }

  private buildSnapshot(): Snapshot {
    const now = performance.now();
    const people = this.tracker.people.slice().sort((a, b) => a.num - b.num);
    const participants: PInfo[] = people.map((t) => ({
      id: t.id,
      num: t.num,
      state: this.tracker.stateOf(t, now),
      excluded: t.excluded,
      locked: t.locked,
      manual: t.manual,
    }));
    return {
      version: this.version,
      participants,
      phase: this.phase,
      winnerId: this.winnerId,
      selectedId: this.selectedId,
      history: this.history,
      round: this.round,
      eligible: participants.filter((p) => !p.excluded).length,
      total: participants.length,
    };
  }

  private signature(now: number) {
    return this.tracker.people.map((t) => `${t.id}${this.tracker.stateOf(t, now)[0]}`).join(",");
  }

  get busy() {
    return this.phase === "spinning" || this.phase === "tension";
  }

  // ---------- детекция ----------
  ingest(cands: Candidate[], region: Box, now: number) {
    if (this.tracker.update(cands, region, now)) this.emit();
  }

  /** Вызывается каждый кадр. */
  step(dt: number, now: number) {
    this.tracker.step(dt, now);
    if (this.phase === "spinning" || this.phase === "tension") this.advanceSpin(now);
    if (now - this.lastSigCheck > 400) {
      this.lastSigCheck = now;
      const s = this.signature(now);
      if (s !== this.sig) {
        this.sig = s;
        this.emit();
      }
    }
  }

  // ---------- рулетка ----------
  eligibleIds(): number[] {
    return this.tracker.people.filter((t) => !t.excluded).map((t) => t.id);
  }

  spin(): boolean {
    if (this.busy) return false;
    const ids = this.eligibleIds();
    if (ids.length === 0) return false;
    this.winnerId = null;
    this.highlightId = null;
    this.selectedId = null;
    this.draft = null;
    this.tracker.membershipLocked = true; // фиксируем список участников
    this.plan = buildPlan(ids, this.durationMs);
    this.startAt = performance.now();
    this.stepIdx = -1;
    this.tensionSent = false;
    this.phase = "spinning";
    this.emit();
    this.onEvent?.({ type: "start" });
    return true;
  }

  private advanceSpin(now: number) {
    const plan = this.plan;
    if (!plan) return;
    const el = now - this.startAt;
    while (this.stepIdx + 1 < plan.steps.length && plan.steps[this.stepIdx + 1].at <= el) {
      this.stepIdx++;
      const s = plan.steps[this.stepIdx];
      this.highlightId = s.id;
      this.onEvent?.({ type: "tick", p: s.p });
    }
    if (!this.tensionSent && el >= plan.tensionAt) {
      this.tensionSent = true;
      this.phase = "tension";
      this.emit();
      this.onEvent?.({ type: "tension" });
    }
    if (el >= plan.revealAt) this.reveal(plan.winnerId);
  }

  private reveal(id: number) {
    const t = this.tracker.get(id);
    const pool = this.eligibleIds().length;
    this.phase = "reveal";
    this.winnerId = id;
    this.highlightId = id;
    this.plan = null;
    this.tracker.membershipLocked = false;
    if (t) {
      if (this.excludeWinners) t.excluded = true;
      this.history = [
        { round: this.round, id, num: t.num, at: Date.now(), pool },
        ...this.history,
      ].slice(0, 100);
      this.round++;
    }
    this.emit();
    this.onEvent?.({ type: "reveal" });
  }

  /** СБРОСИТЬ: прервать розыгрыш, вернуть всех исключённых, снять подсветку. */
  reset() {
    this.plan = null;
    this.phase = "idle";
    this.winnerId = null;
    this.highlightId = null;
    this.tracker.membershipLocked = false;
    for (const t of this.tracker.tracks) t.excluded = false;
    this.emit();
  }

  clearHistory() {
    this.history = [];
    this.round = 1;
    this.emit();
  }

  // ---------- ручное управление участниками ----------
  select(id: number | null) {
    if (this.selectedId !== id) {
      this.selectedId = id;
      this.emit();
    }
  }

  setExcluded(id: number, v: boolean) {
    const t = this.tracker.get(id);
    if (!t || this.busy) return;
    t.excluded = v;
    if (this.winnerId === id && v === false) this.winnerId = null;
    this.emit();
  }

  toggleLock(id: number) {
    const t = this.tracker.get(id);
    if (!t) return;
    t.locked = !t.locked;
    if (!t.locked) t.lastSeen = performance.now();
    this.emit();
  }

  removeParticipant(id: number) {
    if (this.busy) return;
    this.tracker.remove(id);
    if (this.selectedId === id) this.selectedId = null;
    if (this.winnerId === id) {
      this.winnerId = null;
      this.highlightId = null;
      this.phase = "idle";
    }
    this.emit();
  }

  addManual(box?: Box): number | null {
    if (this.busy) return null;
    const b = box ?? { x: 0.44, y: 0.35, w: 0.12, h: 0.3 };
    const t = this.tracker.addManual(clampBox(b), performance.now());
    this.selectedId = t.id;
    this.emit();
    return t.id;
  }

  clearAll() {
    if (this.busy) return;
    this.tracker.clear();
    this.selectedId = null;
    this.winnerId = null;
    this.highlightId = null;
    this.phase = "idle";
    this.emit();
  }

  lockAll(v: boolean) {
    for (const t of this.tracker.people) {
      t.locked = v;
      if (!v) t.lastSeen = performance.now();
    }
    this.emit();
  }

  // ---------- модель для рендера ----------
  toModel(now: number, editing: boolean): RModel {
    const boxes = [];
    for (const t of this.tracker.tracks) {
      if (!t.confirmed) continue;
      boxes.push({
        id: t.id,
        num: t.num,
        x: t.disp.x,
        y: t.disp.y,
        w: t.disp.w,
        h: t.disp.h,
        st: this.tracker.stateOf(t, now),
        excluded: t.excluded,
        locked: t.locked,
      });
    }
    return {
      boxes,
      phase: this.phase,
      highlightId: this.highlightId,
      winnerId: this.winnerId,
      selectedId: this.selectedId,
      mirror: this.mirror,
      editing,
      draft: this.draft,
    };
  }
}
