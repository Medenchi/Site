import { useCallback, useState } from "react";

export interface RemoteSettings {
  enabled: boolean;
  url: string;
  token: string;
  sendVideo: boolean;
}

export interface Settings {
  durationSec: number;
  sound: boolean;
  excludeWinners: boolean;
  mirror: boolean;
  accuracy: "fast" | "high";
  sensitivity: number;
  /** Сколько секунд держать рамку без обнаружения (0 = всегда). */
  holdSec: number;
  deviceId: string;
  remote: RemoteSettings;
}

export const DEFAULT_SETTINGS: Settings = {
  durationSec: 8,
  sound: true,
  excludeWinners: true,
  mirror: true,
  accuracy: "fast",
  sensitivity: 0.55,
  holdSec: 45,
  deviceId: "",
  remote: { enabled: false, url: "", token: "", sendVideo: false },
};

const KEY = "class-roulette:settings:v1";

function load(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const p = JSON.parse(raw) as Partial<Settings>;
    return { ...DEFAULT_SETTINGS, ...p, remote: { ...DEFAULT_SETTINGS.remote, ...(p.remote ?? {}) } };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function useSettings(): [Settings, (patch: Partial<Settings>) => void] {
  const [s, setS] = useState<Settings>(load);
  const update = useCallback((patch: Partial<Settings>) => {
    setS((prev) => {
      const next = { ...prev, ...patch };
      try {
        localStorage.setItem(KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);
  return [s, update];
}
