import { FaceDetector, FilesetResolver, PoseLandmarker } from "@mediapipe/tasks-vision";
import { ASSETS } from "../config";
import {
  Box,
  Candidate,
  FULL_BOX,
  center,
  clamp,
  iou,
  pointInBox,
  unionBox,
} from "./geometry";

type NL = { x: number; y: number; z?: number; visibility?: number };

export type DetectorStatus = "idle" | "loading" | "ready" | "error";

interface PoseCand {
  box: Box;
  score: number;
  head: { x: number; y: number } | null;
}

async function exists(url: string): Promise<boolean> {
  try {
    const r = await fetch(url, { method: "HEAD", cache: "force-cache" });
    if (!r.ok) return false;
    const ct = r.headers.get("content-type") ?? "";
    return !ct.includes("text/html");
  } catch {
    return false;
  }
}

/** Рамка «человека» по ключевым точкам позы: голова + плечи + верх корпуса. */
function poseToCand(lm: NL[]): PoseCand | null {
  const vis = (i: number) => lm[i]?.visibility ?? 0;
  const headPts = [0, 2, 5, 7, 8].filter((i) => vis(i) > 0.3).map((i) => lm[i]);
  const shOk = vis(11) > 0.35 && vis(12) > 0.35;
  if (!shOk && headPts.length < 2) return null;

  let x0: number, x1: number, y0: number, y1: number;
  let score: number;
  let head: { x: number; y: number } | null = null;
  if (headPts.length) {
    head = {
      x: headPts.reduce((s, p) => s + p.x, 0) / headPts.length,
      y: headPts.reduce((s, p) => s + p.y, 0) / headPts.length,
    };
  }

  if (shOk) {
    const sw = Math.abs(lm[11].x - lm[12].x);
    if (sw < 0.02) return null;
    const cx = (lm[11].x + lm[12].x) / 2;
    const sy = (lm[11].y + lm[12].y) / 2;
    const half = sw * 0.68;
    x0 = cx - half;
    x1 = cx + half;
    const top = headPts.length ? Math.min(...headPts.map((p) => p.y)) : sy - sw * 0.9;
    y0 = top - sw * 0.3;
    y1 = sy + sw * 1.1;
    if (vis(23) > 0.5 && vis(24) > 0.5) {
      const hy = (lm[23].y + lm[24].y) / 2;
      if (hy > sy && hy < sy + sw * 2.8) y1 = Math.max(y1, hy);
    }
    for (const p of headPts) {
      x0 = Math.min(x0, p.x - sw * 0.18);
      x1 = Math.max(x1, p.x + sw * 0.18);
    }
    // рука у лица (закрытое лицо) — расширяем вверх/вбок, но не уводим рамку на парту
    for (const i of [15, 16]) {
      if (vis(i) > 0.4 && lm[i].y < sy && lm[i].x > x0 - sw * 0.3 && lm[i].x < x1 + sw * 0.3) {
        x0 = Math.min(x0, lm[i].x - sw * 0.1);
        x1 = Math.max(x1, lm[i].x + sw * 0.1);
        y0 = Math.min(y0, lm[i].y - sw * 0.1);
      }
    }
    score = (vis(11) + vis(12)) / 2;
  } else {
    const hx0 = Math.min(...headPts.map((p) => p.x));
    const hx1 = Math.max(...headPts.map((p) => p.x));
    const hy0 = Math.min(...headPts.map((p) => p.y));
    const hy1 = Math.max(...headPts.map((p) => p.y));
    const hw = Math.max(hx1 - hx0, 0.03);
    const cx = (hx0 + hx1) / 2;
    x0 = cx - hw * 1.7;
    x1 = cx + hw * 1.7;
    y0 = hy0 - hw * 0.8;
    y1 = hy1 + hw * 2.4;
    score = headPts.reduce((s, p) => s + (p.visibility ?? 0), 0) / headPts.length;
  }

  x0 = clamp(x0, 0, 1);
  x1 = clamp(x1, 0, 1);
  y0 = clamp(y0, 0, 1);
  y1 = clamp(y1, 0, 1);
  if (x1 - x0 < 0.03 || y1 - y0 < 0.05) return null;
  return { box: { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, score, head };
}

/** Рамка человека по найденному лицу (когда поза не распознана). */
function faceToBody(f: Box): Box {
  const w = f.w * 3.0;
  const h = f.h * 3.6;
  const x = clamp(f.x + f.w / 2 - w / 2, 0, 1);
  const y = clamp(f.y - f.h * 0.4, 0, 1);
  return { x, y, w: Math.min(w, 1 - x), h: Math.min(h, 1 - y) };
}

export class Detector {
  private face: FaceDetector | null = null;
  private pose: PoseLandmarker | null = null;
  private work: HTMLCanvasElement | null = null;
  private wctx: CanvasRenderingContext2D | null = null;
  status: DetectorStatus = "idle";
  delegate: "GPU" | "CPU" = "GPU";
  error = "";
  private initPromise: Promise<void> | null = null;

  init(): Promise<void> {
    if (!this.initPromise) {
      this.status = "loading";
      this.initPromise = this.doInit().catch((e) => {
        this.status = "error";
        this.error = e instanceof Error ? e.message : String(e);
        this.initPromise = null;
        throw e;
      });
    }
    return this.initPromise;
  }

  private async doInit() {
    const localOk = await exists(`${ASSETS.wasmLocal}/vision_wasm_internal.wasm`);
    const wasm = localOk ? ASSETS.wasmLocal : ASSETS.wasmCdn;
    const faceUrl = (await exists(ASSETS.faceLocal)) ? ASSETS.faceLocal : ASSETS.faceCdn;
    const poseUrl = (await exists(ASSETS.poseLocal)) ? ASSETS.poseLocal : ASSETS.poseCdn;
    const fileset = await FilesetResolver.forVisionTasks(wasm);

    const make = async (delegate: "GPU" | "CPU") => {
      const face = await FaceDetector.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: faceUrl, delegate },
        runningMode: "IMAGE",
        minDetectionConfidence: 0.45,
      });
      const pose = await PoseLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: poseUrl, delegate },
        runningMode: "IMAGE",
        numPoses: 16,
        minPoseDetectionConfidence: 0.4,
        minPosePresenceConfidence: 0.4,
        minTrackingConfidence: 0.4,
      });
      return { face, pose };
    };

    try {
      const r = await make("GPU");
      this.face = r.face;
      this.pose = r.pose;
      this.delegate = "GPU";
    } catch (e) {
      console.warn("GPU delegate unavailable, fallback to CPU", e);
      const r = await make("CPU");
      this.face = r.face;
      this.pose = r.pose;
      this.delegate = "CPU";
    }
    this.status = "ready";
  }

  /** Чувствительность 0..1 (больше = находит больше, но больше ложных). */
  setSensitivity(s: number) {
    const conf = clamp(0.7 - s * 0.45, 0.2, 0.7);
    try {
      void this.face?.setOptions({ minDetectionConfidence: conf });
      void this.pose?.setOptions({
        minPoseDetectionConfidence: conf - 0.05,
        minPosePresenceConfidence: conf - 0.05,
      });
    } catch {
      /* ignore */
    }
  }

  /**
   * Один проход детекции. `region` — часть кадра (нормализованная); для
   * режима высокой точности кадр обрабатывается по частям.
   */
  detect(video: HTMLVideoElement, region: Box): Candidate[] {
    if (!this.face || !this.pose) return [];
    const vw = video.videoWidth;
    const vh = video.videoHeight;
    if (!vw || !vh) return [];

    let src: HTMLVideoElement | HTMLCanvasElement = video;
    const full = region === FULL_BOX || (region.w >= 0.999 && region.h >= 0.999);
    let iw = vw;
    let ih = vh;
    if (!full) {
      const sx = region.x * vw;
      const sy = region.y * vh;
      const sw = region.w * vw;
      const sh = region.h * vh;
      const scale = Math.min(1, 1280 / sw);
      iw = Math.max(64, Math.round(sw * scale));
      ih = Math.max(64, Math.round(sh * scale));
      if (!this.work) {
        this.work = document.createElement("canvas");
        this.wctx = this.work.getContext("2d", { alpha: false });
      }
      if (this.work.width !== iw) this.work.width = iw;
      if (this.work.height !== ih) this.work.height = ih;
      this.wctx!.drawImage(video, sx, sy, sw, sh, 0, 0, iw, ih);
      src = this.work;
    }

    const toFrame = (b: Box): Box => ({
      x: region.x + b.x * region.w,
      y: region.y + b.y * region.h,
      w: b.w * region.w,
      h: b.h * region.h,
    });

    // --- поза ---
    const poses: PoseCand[] = [];
    const pr = this.pose.detect(src);
    for (const lm of pr.landmarks) {
      const c = poseToCand(lm as NL[]);
      if (c) {
        poses.push({
          box: toFrame(c.box),
          score: c.score,
          head: c.head ? { x: region.x + c.head.x * region.w, y: region.y + c.head.y * region.h } : null,
        });
      }
    }
    poses.sort((a, b) => b.score - a.score);
    const nms: PoseCand[] = [];
    for (const p of poses) if (!nms.some((q) => iou(q.box, p.box) > 0.5)) nms.push(p);

    // --- лица ---
    const faces: Box[] = [];
    const fr = this.face.detect(src);
    for (const d of fr.detections) {
      const bb = d.boundingBox;
      if (!bb) continue;
      faces.push(
        toFrame({ x: bb.originX / iw, y: bb.originY / ih, w: bb.width / iw, h: bb.height / ih })
      );
    }

    // --- объединение: лицо привязывается к позе, иначе — самостоятельный кандидат ---
    const out: Candidate[] = [];
    const used = new Set<number>();
    for (const f of faces) {
      const fc = center(f);
      let best = -1;
      let bestD = Infinity;
      nms.forEach((p, i) => {
        if (used.has(i)) return;
        const inHead = p.head ? pointInBox(p.head.x, p.head.y, grow(f, 0.6)) : false;
        const inTop =
          pointInBox(fc.x, fc.y, p.box) && fc.y < p.box.y + p.box.h * 0.6;
        if (!inHead && !inTop) return;
        const d = p.head ? Math.hypot(p.head.x - fc.x, p.head.y - fc.y) : 0.5;
        if (d < bestD) {
          bestD = d;
          best = i;
        }
      });
      if (best >= 0) {
        used.add(best);
        out.push({ box: unionBox(nms[best].box, f), score: 1, kind: "both" });
      } else {
        // нет позы, но есть лицо — строим рамку тела от лица
        out.push({ box: faceToBody(f), score: 0.8, kind: "face" });
      }
    }
    nms.forEach((p, i) => {
      if (!used.has(i)) out.push({ box: p.box, score: p.score, kind: "pose" });
    });
    return out;
  }

  dispose() {
    this.face?.close();
    this.pose?.close();
    this.face = null;
    this.pose = null;
    this.initPromise = null;
    this.status = "idle";
  }
}

function grow(b: Box, k: number): Box {
  return { x: b.x - b.w * k, y: b.y - b.h * k, w: b.w * (1 + 2 * k), h: b.h * (1 + 2 * k) };
}

export const detector = new Detector();
