import type { Game } from "./game";
import { Box, clamp, clampBox, pointInBox } from "./geometry";
import { HANDLE_R } from "./renderer";

export type Tool = "select" | "add";

/** Точка в видовых нормализованных координатах + размеры холста в CSS-px. */
export interface PointerInfo {
  x: number;
  y: number;
  w: number;
  h: number;
  u: number;
}

type Drag =
  | { kind: "move"; id: number; dx: number; dy: number; sx: number; sy: number; moved: boolean }
  | { kind: "resize"; id: number; ax: number; ay: number }
  | { kind: "draw"; x0: number; y0: number };

/**
 * Ручная коррекция хитбоксов мышью/пальцем: выбор, перетаскивание,
 * изменение размера за угловые ручки, рисование новой рамки.
 * Работает в «исходных» координатах кадра (без учёта зеркала).
 */
export class BoxEditor {
  tool: Tool = "select";
  onToolDone?: () => void;
  private drag: Drag | null = null;

  constructor(private game: Game) {}

  get dragging() {
    return this.drag !== null;
  }

  private src(p: PointerInfo) {
    return { x: this.game.mirror ? 1 - p.x : p.x, y: p.y };
  }

  down(p: PointerInfo): boolean {
    const g = this.game;
    if (g.busy) return false;
    const s = this.src(p);

    if (this.tool === "add") {
      this.drag = { kind: "draw", x0: s.x, y0: s.y };
      g.draft = { x: s.x, y: s.y, w: 0, h: 0 };
      return true;
    }

    // ручки изменения размера у выбранной рамки
    const sel = g.selectedId !== null ? g.tracker.get(g.selectedId) : undefined;
    if (sel) {
      const b = sel.disp;
      const corners: [number, number, number, number][] = [
        [b.x, b.y, b.x + b.w, b.y + b.h],
        [b.x + b.w, b.y, b.x, b.y + b.h],
        [b.x, b.y + b.h, b.x + b.w, b.y],
        [b.x + b.w, b.y + b.h, b.x, b.y],
      ];
      const rad = HANDLE_R * p.u * 1.8;
      for (const [cx, cy, ax, ay] of corners) {
        if (Math.hypot((s.x - cx) * p.w, (s.y - cy) * p.h) < rad) {
          this.drag = { kind: "resize", id: sel.id, ax, ay };
          return true;
        }
      }
    }

    // попадание в рамку: берём самую маленькую из подходящих
    const pad = (6 * p.u) / p.w;
    let hit: (typeof g.tracker.tracks)[number] | null = null;
    for (const t of g.tracker.tracks) {
      if (!t.confirmed) continue;
      if (!pointInBox(s.x, s.y, t.disp, pad)) continue;
      if (!hit || t.disp.w * t.disp.h < hit.disp.w * hit.disp.h) hit = t;
    }
    if (hit) {
      g.select(hit.id);
      this.drag = { kind: "move", id: hit.id, dx: s.x - hit.box.x, dy: s.y - hit.box.y, sx: p.x * p.w, sy: p.y * p.h, moved: false };
      return true;
    }
    g.select(null);
    return false;
  }

  move(p: PointerInfo) {
    const d = this.drag;
    if (!d) return;
    const g = this.game;
    const s = this.src(p);
    const now = performance.now();

    if (d.kind === "draw") {
      g.draft = {
        x: Math.min(d.x0, s.x),
        y: Math.min(d.y0, s.y),
        w: Math.abs(s.x - d.x0),
        h: Math.abs(s.y - d.y0),
      };
    } else if (d.kind === "move") {
      const t = g.tracker.get(d.id);
      if (!t) return;
      if (!d.moved) {
        if (Math.hypot(p.x * p.w - d.sx, p.y * p.h - d.sy) < 5 * p.u) return;
        d.moved = true;
      }
      const x = clamp(s.x - d.dx, 0, 1 - t.box.w);
      const y = clamp(s.y - d.dy, 0, 1 - t.box.h);
      g.tracker.setBox(d.id, { x, y, w: t.box.w, h: t.box.h }, now);
    } else {
      const nb: Box = {
        x: Math.min(d.ax, s.x),
        y: Math.min(d.ay, s.y),
        w: Math.abs(s.x - d.ax),
        h: Math.abs(s.y - d.ay),
      };
      const cb = clampBox(nb);
      // при минимальном размере держим якорный угол на месте
      if (nb.w < 0.03) cb.x = s.x < d.ax ? d.ax - cb.w : d.ax;
      if (nb.h < 0.03) cb.y = s.y < d.ay ? d.ay - cb.h : d.ay;
      g.tracker.setBox(d.id, cb, now);
    }
  }

  up(p: PointerInfo) {
    const d = this.drag;
    if (!d) return;
    const g = this.game;
    this.drag = null;
    if (d.kind === "draw") {
      const dr = g.draft;
      g.draft = null;
      const s = this.src(p);
      if (dr && dr.w > 0.02 && dr.h > 0.03) {
        g.addManual(dr);
      } else {
        g.addManual({ x: s.x - 0.06, y: s.y - 0.15, w: 0.12, h: 0.3 });
      }
      this.tool = "select";
      this.onToolDone?.();
    } else {
      g.emit();
    }
  }

  cancel() {
    this.drag = null;
    this.game.draft = null;
  }
}
