import type { Phase, RBox, RModel } from "./types";

const BRASS = "217,178,106";
const AMBER = "255,179,71";
const HOT = "255,106,42";
const BLOOD = "255,36,24";

/** Радиус угловой ручки (CSS-пиксели при масштабе 1). */
export const HANDLE_R = 15;

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

/**
 * Рисует рамки, подсветку, эффекты. Один Canvas на всё приложение —
 * никаких временных canvas в кадре.
 */
export class StageRenderer {
  private ctx: CanvasRenderingContext2D;
  private W = 0;
  private H = 0;
  private dpr = 1;
  private u = 1;
  private glow = new Map<number, number>();
  private lastPhase: Phase = "idle";
  private revealAt = 0;
  private lastNow = 0;

  constructor(private canvas: HTMLCanvasElement) {
    this.ctx = canvas.getContext("2d", { alpha: true, desynchronized: true })!;
  }

  resize(cssW: number, cssH: number, dpr: number, u: number) {
    this.W = cssW;
    this.H = cssH;
    this.dpr = dpr;
    this.u = u;
    const pw = Math.max(1, Math.round(cssW * dpr));
    const ph = Math.max(1, Math.round(cssH * dpr));
    if (this.canvas.width !== pw) this.canvas.width = pw;
    if (this.canvas.height !== ph) this.canvas.height = ph;
  }

  private px(b: RBox, mirror: boolean) {
    const x = (mirror ? 1 - (b.x + b.w) : b.x) * this.W;
    return { x, y: b.y * this.H, w: b.w * this.W, h: b.h * this.H };
  }

  draw(m: RModel, now: number) {
    const { ctx, W, H, u } = this;
    const dt = clamp((now - this.lastNow) / 1000, 0.001, 0.1);
    this.lastNow = now;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    if (W < 4) return;

    if (m.phase === "reveal" && this.lastPhase !== "reveal") this.revealAt = now;
    this.lastPhase = m.phase;
    const spinning = m.phase === "spinning" || m.phase === "tension";
    const reveal = m.phase === "reveal" && m.winnerId !== null;
    const el = now - this.revealAt;

    // затухание свечения
    const alive = new Set<number>();
    for (const b of m.boxes) {
      alive.add(b.id);
      let g = this.glow.get(b.id) ?? 0;
      const target = spinning && b.id === m.highlightId ? 1 : 0;
      g = target > g ? g + (target - g) * (1 - Math.exp(-dt * 45)) : g * Math.exp(-dt * 5.5);
      this.glow.set(b.id, g < 0.01 ? 0 : g);
    }
    for (const id of this.glow.keys()) if (!alive.has(id)) this.glow.delete(id);

    ctx.save();
    if (reveal && el < 650) {
      const mag = (1 - el / 650) * 11 * u;
      ctx.translate((Math.random() - 0.5) * mag, (Math.random() - 0.5) * mag);
    }

    // ---- 1. обычные рамки ----
    let win: RBox | null = null;
    let hot: RBox | null = null;
    for (const b of m.boxes) {
      if (reveal && b.id === m.winnerId) {
        win = b;
        continue;
      }
      if (spinning && (this.glow.get(b.id) ?? 0) > 0.02 && !b.excluded) {
        if (b.id === m.highlightId) {
          hot = b;
          continue;
        }
      }
      this.drawBase(b, m, spinning, this.glow.get(b.id) ?? 0, now);
    }
    if (hot) this.drawBase(hot, m, spinning, this.glow.get(hot.id) ?? 1, now);

    // ---- 2. напряжение: пульс по краям ----
    if (m.phase === "tension") {
      const t = (now % 880) / 880;
      const pulse = Math.exp(-Math.pow((t - 0.05) * 10, 2)) + 0.6 * Math.exp(-Math.pow((t - 0.27) * 10, 2));
      const gr = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
      gr.addColorStop(0, "rgba(120,0,0,0)");
      gr.addColorStop(1, `rgba(150,0,0,${0.18 + 0.4 * pulse})`);
      ctx.fillStyle = gr;
      ctx.fillRect(0, 0, W, H);
    }

    // ---- 3. результат ----
    if (win) {
      const r = this.px(win, m.mirror);
      const a = Math.min(1, el / 320);
      ctx.fillStyle = `rgba(6,2,1,${0.8 * a})`;
      ctx.beginPath();
      ctx.rect(-50, -50, W + 100, H + 100);
      ctx.rect(r.x, r.y, r.w, r.h);
      ctx.fill("evenodd");
      const gr = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.8);
      gr.addColorStop(0, "rgba(120,0,0,0)");
      gr.addColorStop(1, `rgba(140,0,0,${0.55 * a})`);
      ctx.fillStyle = gr;
      ctx.fillRect(0, 0, W, H);

      const pulse = 0.5 + 0.5 * Math.sin(now / 170);
      // расходящиеся кольца
      for (let k = 0; k < 2; k++) {
        const ph = (((now - this.revealAt) / 1300 + k * 0.5) % 1 + 1) % 1;
        const inf = ph * 38 * u;
        ctx.strokeStyle = `rgba(${BLOOD},${(1 - ph) * 0.55})`;
        ctx.lineWidth = 4 * u;
        ctx.strokeRect(r.x - inf, r.y - inf, r.w + inf * 2, r.h + inf * 2);
      }
      ctx.save();
      ctx.shadowColor = `rgba(${BLOOD},0.95)`;
      ctx.shadowBlur = (40 + 30 * pulse) * u;
      ctx.fillStyle = `rgba(${BLOOD},${0.26 + 0.1 * pulse})`;
      ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.strokeStyle = `rgb(${BLOOD})`;
      ctx.lineWidth = 7 * u;
      ctx.strokeRect(r.x, r.y, r.w, r.h);
      ctx.restore();
      this.brackets(r, `rgb(255,225,215)`, 8 * u, Math.min(r.w, r.h) * 0.22);
      this.plate(r, `№${win.num}`, "blood", 1.35);

      if (el < 450) {
        ctx.fillStyle = `rgba(255,235,225,${0.7 * (1 - el / 450)})`;
        ctx.fillRect(-50, -50, W + 100, H + 100);
      }
    }
    ctx.restore();

    // ---- 4. рисуемая рамка ----
    if (m.draft) {
      const d = m.draft;
      const x = (m.mirror ? 1 - (d.x + d.w) : d.x) * W;
      ctx.save();
      ctx.setLineDash([10 * u, 7 * u]);
      ctx.strokeStyle = `rgb(${AMBER})`;
      ctx.lineWidth = 3 * u;
      ctx.fillStyle = `rgba(${AMBER},0.12)`;
      ctx.fillRect(x, d.y * H, d.w * W, d.h * H);
      ctx.strokeRect(x, d.y * H, d.w * W, d.h * H);
      ctx.restore();
    }
  }

  private drawBase(b: RBox, m: RModel, spinning: boolean, glow: number, now: number) {
    const { ctx, u } = this;
    const r = this.px(b, m.mirror);
    const selected = m.editing && m.selectedId === b.id;
    const inReveal = m.phase === "reveal";
    const tension = m.phase === "tension";

    if (b.excluded) {
      ctx.fillStyle = "rgba(0,0,0,0.38)";
      ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.save();
      ctx.setLineDash([6 * u, 6 * u]);
      ctx.strokeStyle = `rgba(160,150,140,${spinning ? 0.25 : 0.55})`;
      ctx.lineWidth = 2 * u;
      ctx.strokeRect(r.x, r.y, r.w, r.h);
      ctx.restore();
      if (!spinning) {
        const fs = clamp(r.h * 0.12, 14 * u, 30 * u);
        ctx.font = `${fs}px "Russo One", sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = "rgba(225,205,175,0.55)";
        ctx.fillText("ВЫБЫЛ", r.x + r.w / 2, r.y + r.h / 2);
      }
      this.plate(r, `№${b.num}`, "dead", 0.85);
      if (selected) this.handles(r);
      return;
    }

    const held = b.st === "held";
    const baseAlpha = spinning ? 0.55 : 1;

    ctx.fillStyle = `rgba(255,214,140,${0.07 * baseAlpha})`;
    ctx.fillRect(r.x, r.y, r.w, r.h);

    ctx.save();
    if (held) ctx.setLineDash([12 * u, 8 * u]);
    ctx.strokeStyle = `rgba(${BRASS},${(held ? 0.7 : 0.9) * baseAlpha})`;
    ctx.lineWidth = (selected ? 4.5 : 2.5) * u;
    ctx.strokeRect(r.x, r.y, r.w, r.h);
    ctx.restore();
    if (!held) this.brackets(r, `rgba(${BRASS},${baseAlpha})`, 5 * u, Math.min(r.w, r.h) * 0.17);

    let plateStyle: "brass" | "amber" | "hot" = "brass";
    if (glow > 0.01) {
      const col = tension ? HOT : AMBER;
      ctx.save();
      ctx.shadowColor = `rgba(${col},${0.95 * glow})`;
      ctx.shadowBlur = 46 * u * glow;
      ctx.fillStyle = `rgba(${col},${0.38 * glow})`;
      ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.strokeStyle = `rgba(${col},${glow})`;
      ctx.lineWidth = 6 * u;
      ctx.strokeRect(r.x, r.y, r.w, r.h);
      ctx.restore();
      this.brackets(r, `rgba(255,240,200,${glow})`, 7 * u, Math.min(r.w, r.h) * 0.22);
      plateStyle = tension ? "hot" : "amber";
    }
    this.plate(r, `№${b.num}`, plateStyle, 1 + glow * 0.2);

    if (!spinning && !inReveal && b.locked && m.editing) this.lock(r);
    if (selected) {
      ctx.save();
      ctx.setLineDash([4 * u, 6 * u]);
      ctx.strokeStyle = "rgba(255,245,220,0.9)";
      ctx.lineWidth = 2 * u;
      const o = 6 * u;
      ctx.strokeRect(r.x - o, r.y - o, r.w + o * 2, r.h + o * 2);
      ctx.restore();
      this.handles(r);
    }
    void now;
  }

  private brackets(r: { x: number; y: number; w: number; h: number }, color: string, lw: number, len: number) {
    const { ctx } = this;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = lw;
    ctx.lineCap = "square";
    ctx.beginPath();
    const { x, y, w, h } = r;
    ctx.moveTo(x, y + len);
    ctx.lineTo(x, y);
    ctx.lineTo(x + len, y);
    ctx.moveTo(x + w - len, y);
    ctx.lineTo(x + w, y);
    ctx.lineTo(x + w, y + len);
    ctx.moveTo(x + w, y + h - len);
    ctx.lineTo(x + w, y + h);
    ctx.lineTo(x + w - len, y + h);
    ctx.moveTo(x + len, y + h);
    ctx.lineTo(x, y + h);
    ctx.lineTo(x, y + h - len);
    ctx.stroke();
    ctx.restore();
  }

  /** Табличка с номером участника. */
  private plate(
    r: { x: number; y: number; w: number; h: number },
    text: string,
    style: "brass" | "amber" | "hot" | "blood" | "dead",
    scale: number
  ) {
    const { ctx, u } = this;
    const fs = clamp(Math.min(r.h * 0.2, r.w * 0.3), 20 * u, 54 * u) * scale;
    ctx.font = `${fs}px "Russo One", "Oswald", sans-serif`;
    const tw = ctx.measureText(text).width;
    const padX = fs * 0.4;
    const ph = fs * 1.35;
    const pw = tw + padX * 2;
    const px = clamp(r.x, 0, this.W - pw);
    let py = r.y - ph + 2 * u;
    if (py < 0) py = r.y + 2 * u;
    const pal = {
      brass: ["#2a170c", `rgb(${BRASS})`, "#f6dc9a"],
      amber: [`rgb(${AMBER})`, "#fff0c0", "#2a1206"],
      hot: [`rgb(${HOT})`, "#ffd2b0", "#2a0a02"],
      blood: ["#d11a10", "#ffd9d2", "#ffffff"],
      dead: ["#2b2622", "#6e655c", "#a89c8e"],
    }[style];
    ctx.save();
    ctx.fillStyle = pal[0];
    ctx.strokeStyle = pal[1];
    ctx.lineWidth = 2.5 * u;
    ctx.beginPath();
    ctx.roundRect(px, py, pw, ph, 5 * u);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = pal[2];
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text, px + pw / 2, py + ph / 2 + fs * 0.04);
    ctx.restore();
  }

  private handles(r: { x: number; y: number; w: number; h: number }) {
    const { ctx, u } = this;
    const R = HANDLE_R * u;
    ctx.save();
    for (const [cx, cy] of [
      [r.x, r.y],
      [r.x + r.w, r.y],
      [r.x, r.y + r.h],
      [r.x + r.w, r.y + r.h],
    ]) {
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = "#2a170c";
      ctx.fill();
      ctx.lineWidth = 3.5 * u;
      ctx.strokeStyle = "#f6dc9a";
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.32, 0, Math.PI * 2);
      ctx.fillStyle = "#f6dc9a";
      ctx.fill();
    }
    ctx.restore();
  }

  private lock(r: { x: number; y: number; w: number; h: number }) {
    const { ctx, u } = this;
    const s = 9 * u;
    const x = r.x + r.w - s * 2.2;
    const y = r.y + s * 0.9;
    ctx.save();
    ctx.fillStyle = `rgba(${BRASS},0.95)`;
    ctx.strokeStyle = `rgba(${BRASS},0.95)`;
    ctx.lineWidth = 2.4 * u;
    ctx.fillRect(x, y + s * 0.8, s * 1.4, s * 1.1);
    ctx.beginPath();
    ctx.arc(x + s * 0.7, y + s * 0.8, s * 0.5, Math.PI, 0);
    ctx.stroke();
    ctx.restore();
  }
}
