import type { TrackState } from "./tracker";

export type Phase = "idle" | "spinning" | "tension" | "reveal";

export interface HistoryEntry {
  round: number;
  id: number;
  num: number;
  at: number;
  pool: number;
}

/** Рамка для отрисовки. */
export interface RBox {
  id: number;
  num: number;
  x: number;
  y: number;
  w: number;
  h: number;
  st: TrackState;
  excluded: boolean;
  locked: boolean;
}

/** Всё, что нужно рендереру (используется и локально, и в серверном режиме). */
export interface RModel {
  boxes: RBox[];
  phase: Phase;
  highlightId: number | null;
  winnerId: number | null;
  selectedId: number | null;
  mirror: boolean;
  editing: boolean;
  draft: { x: number; y: number; w: number; h: number } | null;
}

export interface PInfo {
  id: number;
  num: number;
  state: TrackState;
  excluded: boolean;
  locked: boolean;
  manual: boolean;
}

export interface Snapshot {
  version: number;
  participants: PInfo[];
  phase: Phase;
  winnerId: number | null;
  selectedId: number | null;
  history: HistoryEntry[];
  round: number;
  /** сколько в игре (не исключены) */
  eligible: number;
  total: number;
}

export type GameEvent =
  | { type: "start" }
  | { type: "tick"; p: number }
  | { type: "tension" }
  | { type: "reveal" };

/** Состояние, передаваемое на экран-табло в серверном режиме. */
export interface RemoteState {
  v: 1;
  ts: number;
  aspect: number;
  hasVideo: boolean;
  model: RModel;
  snapshot: Omit<Snapshot, "version">;
}
