import {
  Box,
  Candidate,
  center,
  centerDist,
  clampBox,
  iou,
  overlapMin,
  pointInBox,
  FULL_BOX,
} from "./geometry";

export type TrackState = "tentative" | "tracked" | "held";

export interface Track {
  id: number;
  /** Номер участника (выдаётся при подтверждении, не переиспользуется). */
  num: number;
  /** Целевая (сглаженная) рамка. */
  box: Box;
  /** Рамка, отображаемая на экране (плавно догоняет целевую). */
  disp: Box;
  vx: number;
  vy: number;
  hits: number;
  missed: number;
  firstSeen: number;
  lastSeen: number;
  confirmed: boolean;
  /** Добавлен вручную — никогда не пропадает сам. */
  manual: boolean;
  /** Закреплён: рамка не следует за детектором (но дубликаты рядом не создаются). */
  locked: boolean;
  /** Исключён из текущего розыгрыша. */
  excluded: boolean;
}

const CONFIRM_HITS = 3;
const TENTATIVE_MAX_MISSES = 4;
/** Если детектор не видел человека дольше — рамка «удерживается» (пунктир). */
const HELD_AFTER_MS = 700;

export class Tracker {
  tracks: Track[] = [];
  /** Время удержания потерянной рамки, мс (0 = бесконечно). */
  holdMs = 45000;
  /** Во время розыгрыша состав участников заморожен. */
  membershipLocked = false;

  private nextId = 1;
  private nextNum = 1;

  /** Подтверждённые участники. */
  get people(): Track[] {
    return this.tracks.filter((t) => t.confirmed);
  }

  stateOf(t: Track, now: number): TrackState {
    if (!t.confirmed) return "tentative";
    if (t.manual) return "tracked";
    return now - t.lastSeen < HELD_AFTER_MS ? "tracked" : "held";
  }

  /**
   * Обновление по результатам детекции. `region` — часть кадра, которая была
   * проанализирована в этом проходе (в режиме плиток — не весь кадр).
   * Возвращает true, если изменился состав/статус участников.
   */
  update(cands: Candidate[], region: Box, now: number): boolean {
    let changed = false;

    // --- 1. Сопоставление «рамка трека ↔ кандидат» (жадно, по близости) ---
    type Pair = { ti: number; ci: number; cost: number };
    const pairs: Pair[] = [];
    for (let ti = 0; ti < this.tracks.length; ti++) {
      const t = this.tracks[ti];
      const dt = Math.min(0.5, (now - t.lastSeen) / 1000);
      const pred: Box = { x: t.box.x + t.vx * dt, y: t.box.y + t.vy * dt, w: t.box.w, h: t.box.h };
      for (let ci = 0; ci < cands.length; ci++) {
        const c = cands[ci].box;
        const ov = iou(pred, c);
        const d = centerDist(pred, c);
        if (ov > 0.12 || d < 0.55) pairs.push({ ti, ci, cost: d - ov * 0.5 });
      }
    }
    pairs.sort((a, b) => a.cost - b.cost);
    const usedT = new Set<number>();
    const usedC = new Set<number>();
    for (const p of pairs) {
      if (usedT.has(p.ti) || usedC.has(p.ci)) continue;
      usedT.add(p.ti);
      usedC.add(p.ci);
      if (this.apply(this.tracks[p.ti], cands[p.ci], now)) changed = true;
    }

    // --- 2. Не сопоставленные треки: «закрыт»/потерян, но НЕ удаляем ---
    const removed = new Set<number>();
    for (let ti = 0; ti < this.tracks.length; ti++) {
      if (usedT.has(ti)) continue;
      const t = this.tracks[ti];
      const c = center(t.box);
      const inRegion = pointInBox(c.x, c.y, region);
      if (inRegion) t.missed++;
      t.vx *= 0.7;
      t.vy *= 0.7;
      if (!t.confirmed) {
        if (t.missed >= TENTATIVE_MAX_MISSES) removed.add(t.id);
      } else if (
        !this.membershipLocked &&
        !t.manual &&
        !t.locked &&
        this.holdMs > 0 &&
        now - t.lastSeen > this.holdMs
      ) {
        removed.add(t.id);
        changed = true;
      }
    }

    // --- 3. Новые кандидаты (без дублей) ---
    if (!this.membershipLocked) {
      const spawned: Box[] = [];
      for (let ci = 0; ci < cands.length; ci++) {
        if (usedC.has(ci)) continue;
        const b = cands[ci].box;
        if (b.w < 0.03 || b.h < 0.05) continue;
        const dup =
          this.tracks.some((t) => iou(t.box, b) > 0.3 || overlapMin(t.box, b) > 0.5) ||
          spawned.some((s) => iou(s, b) > 0.3 || overlapMin(s, b) > 0.5);
        if (dup) continue;
        spawned.push(b);
        this.tracks.push({
          id: this.nextId++,
          num: 0,
          box: { ...b },
          disp: { ...b },
          vx: 0,
          vy: 0,
          hits: 1,
          missed: 0,
          firstSeen: now,
          lastSeen: now,
          confirmed: false,
          manual: false,
          locked: false,
          excluded: false,
        });
      }
    }

    // --- 4. Слияние дублей, которые «сползлись» на одного человека ---
    const alive = this.tracks.filter((t) => !removed.has(t.id) && t.confirmed);
    for (let i = 0; i < alive.length; i++) {
      for (let j = i + 1; j < alive.length; j++) {
        const a = alive[i];
        const b = alive[j];
        if (removed.has(a.id) || removed.has(b.id)) continue;
        if (iou(a.box, b.box) > 0.62) {
          const drop = b.num > a.num ? b : a;
          if (!drop.manual && !drop.locked && !drop.excluded && !this.membershipLocked) {
            removed.add(drop.id);
            changed = true;
          }
        }
      }
    }

    if (removed.size) this.tracks = this.tracks.filter((t) => !removed.has(t.id));
    return changed;
  }

  private apply(t: Track, c: Candidate, now: number): boolean {
    const dt = Math.max(0.016, (now - t.lastSeen) / 1000);
    let changed = false;
    t.hits++;
    t.missed = 0;
    if (!t.locked) {
      const nb = c.box;
      const oc = center(t.box);
      const nc = center(nb);
      const dx = nc.x - oc.x;
      const dy = nc.y - oc.y;
      const sizeDiff = Math.abs(nb.w - t.box.w) / t.box.w + Math.abs(nb.h - t.box.h) / t.box.h;
      // «мёртвая зона» против дрожания рамки
      if (Math.abs(dx) > 0.004 || Math.abs(dy) > 0.004 || sizeDiff > 0.06) {
        const ap = 0.45;
        const as = 0.22;
        const w = t.box.w + (nb.w - t.box.w) * as;
        const h = t.box.h + (nb.h - t.box.h) * as;
        const cx = oc.x + dx * ap;
        const cy = oc.y + dy * ap;
        t.box = clampBox({ x: cx - w / 2, y: cy - h / 2, w, h });
        const vx = Math.max(-0.5, Math.min(0.5, (dx * ap) / dt));
        const vy = Math.max(-0.5, Math.min(0.5, (dy * ap) / dt));
        t.vx = t.vx * 0.5 + vx * 0.5;
        t.vy = t.vy * 0.5 + vy * 0.5;
      }
    }
    t.lastSeen = now;
    if (!t.confirmed && t.hits >= CONFIRM_HITS) {
      t.confirmed = true;
      t.num = this.nextNum++;
      changed = true;
    }
    return changed;
  }

  /** Покадровое сглаживание отображаемых рамок (вызывается из requestAnimationFrame). */
  step(dt: number, now: number) {
    const k = 1 - Math.exp(-dt * 14);
    for (const t of this.tracks) {
      if (!t.locked) {
        const f = Math.exp(-(now - t.lastSeen) / 350);
        if (f > 0.02) {
          t.box.x += t.vx * dt * f;
          t.box.y += t.vy * dt * f;
          t.box = clampBox(t.box);
        }
      }
      t.disp.x += (t.box.x - t.disp.x) * k;
      t.disp.y += (t.box.y - t.disp.y) * k;
      t.disp.w += (t.box.w - t.disp.w) * k;
      t.disp.h += (t.box.h - t.disp.h) * k;
    }
  }

  get(id: number): Track | undefined {
    return this.tracks.find((t) => t.id === id);
  }

  /** Ручное добавление участника. */
  addManual(box: Box, now: number): Track {
    const b = clampBox(box);
    const t: Track = {
      id: this.nextId++,
      num: this.nextNum++,
      box: b,
      disp: { ...b },
      vx: 0,
      vy: 0,
      hits: CONFIRM_HITS,
      missed: 0,
      firstSeen: now,
      lastSeen: now,
      confirmed: true,
      manual: true,
      locked: true,
      excluded: false,
    };
    this.tracks.push(t);
    return t;
  }

  /** Ручная коррекция положения/размера — закрепляет рамку. */
  setBox(id: number, box: Box, now: number) {
    const t = this.get(id);
    if (!t) return;
    t.box = clampBox(box);
    t.disp = { ...t.box };
    t.vx = 0;
    t.vy = 0;
    t.locked = true;
    t.lastSeen = now;
  }

  remove(id: number) {
    this.tracks = this.tracks.filter((t) => t.id !== id);
  }

  clear() {
    this.tracks = [];
    this.nextNum = 1;
  }

  resetRegionCounters() {
    for (const t of this.tracks) t.missed = 0;
  }
}

export { FULL_BOX };
