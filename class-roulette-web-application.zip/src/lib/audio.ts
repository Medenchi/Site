/** Звуки, синтезируемые на лету (WebAudio) — никаких внешних файлов. */
class Sfx {
  enabled = true;
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private hbTimer: number | null = null;
  private noiseBuf: AudioBuffer | null = null;

  /** Вызывать из обработчика пользовательского жеста. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.7;
      const comp = this.ctx.createDynamicsCompressor();
      this.master.connect(comp);
      comp.connect(this.ctx.destination);
      const len = this.ctx.sampleRate * 1;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  private ok() {
    return this.enabled && this.ctx && this.master && this.ctx.state === "running";
  }

  private noise(t: number, dur: number, freq: number, q: number, gain: number, type: BiquadFilterType = "bandpass") {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.02);
  }

  private tone(t: number, freq: number, dur: number, gain: number, type: OscillatorType = "sine", endFreq?: number) {
    if (!this.ctx || !this.master) return;
    const o = this.ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  /** Деревянный «щелчок» переключения. */
  tick(p: number) {
    if (!this.ok() || !this.ctx) return;
    const t = this.ctx.currentTime;
    const pitch = 1 + p * 0.5;
    this.noise(t, 0.045, 1800 * pitch, 3, 0.5);
    this.tone(t, 220 * pitch, 0.07, 0.35, "triangle", 120 * pitch);
  }

  private beat() {
    if (!this.ok() || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(t, 70, 0.22, 0.9, "sine", 38);
    this.tone(t + 0.2, 62, 0.26, 0.7, "sine", 34);
  }

  startHeartbeat() {
    this.stopHeartbeat();
    this.beat();
    this.hbTimer = window.setInterval(() => this.beat(), 880);
  }

  stopHeartbeat() {
    if (this.hbTimer !== null) {
      clearInterval(this.hbTimer);
      this.hbTimer = null;
    }
  }

  start() {
    if (!this.ok() || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.noise(t, 0.25, 600, 1, 0.5);
    this.tone(t, 140, 0.3, 0.4, "sawtooth", 90);
  }

  reveal() {
    this.stopHeartbeat();
    if (!this.ok() || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.noise(t, 0.9, 900, 0.3, 1.1, "lowpass");
    this.tone(t, 120, 0.9, 1, "sine", 32);
    this.tone(t, 110, 1.4, 0.18, "sawtooth");
    this.tone(t, 165, 1.4, 0.14, "sawtooth");
    this.tone(t, 220, 1.4, 0.1, "sawtooth");
  }
}

export const sfx = new Sfx();
