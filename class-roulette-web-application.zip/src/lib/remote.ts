import { REMOTE_URL } from "../config";
import type { RemoteState } from "./types";

/**
 * СЕРВЕРНЫЙ РЕЖИМ (по умолчанию выключен, см. src/config.ts и README).
 *
 * Устройство с камерой («хост») по сети отправляет на сервер только
 * легковесное состояние: координаты рамок, фазу рулетки, историю.
 * Экран-табло (?role=display) подписывается через SSE и рисует то же самое.
 * Видео передаётся только если явно включена опция sendVideo.
 */
export interface RemoteConfig {
  enabled: boolean;
  url: string;
  token: string;
  sendVideo: boolean;
}

export type RemoteLinkStatus = "off" | "ok" | "error";

const base = (url: string) => (url || REMOTE_URL || "").replace(/\/+$/, "");

export class RemoteHost {
  status: RemoteLinkStatus = "off";
  onStatus?: (s: RemoteLinkStatus) => void;
  private cfg: RemoteConfig = { enabled: false, url: "", token: "", sendVideo: false };
  private inflight = false;
  private frameInflight = false;
  private lastSend = 0;
  private lastFrame = 0;
  private canvas: HTMLCanvasElement | null = null;

  configure(cfg: RemoteConfig) {
    this.cfg = cfg;
    if (!cfg.enabled) this.setStatus("off");
  }

  private setStatus(s: RemoteLinkStatus) {
    if (this.status !== s) {
      this.status = s;
      this.onStatus?.(s);
    }
  }

  private headers(extra: Record<string, string> = {}) {
    return { "x-token": this.cfg.token, ...extra };
  }

  push(state: RemoteState, video: HTMLVideoElement | null, now: number, force = false) {
    if (!this.cfg.enabled) return;
    if (!this.inflight && (force || now - this.lastSend > 60)) {
      this.lastSend = now;
      this.inflight = true;
      fetch(`${base(this.cfg.url)}/api/state`, {
        method: "POST",
        headers: this.headers({ "content-type": "application/json" }),
        body: JSON.stringify(state),
      })
        .then((r) => this.setStatus(r.ok ? "ok" : "error"))
        .catch(() => this.setStatus("error"))
        .finally(() => {
          this.inflight = false;
        });
    }
    if (this.cfg.sendVideo && video && video.videoWidth && !this.frameInflight && now - this.lastFrame > 400) {
      this.lastFrame = now;
      this.frameInflight = true;
      if (!this.canvas) this.canvas = document.createElement("canvas");
      const w = 800;
      const h = Math.round((w * video.videoHeight) / video.videoWidth);
      this.canvas.width = w;
      this.canvas.height = h;
      this.canvas.getContext("2d")!.drawImage(video, 0, 0, w, h);
      this.canvas.toBlob(
        (blob) => {
          if (!blob) {
            this.frameInflight = false;
            return;
          }
          fetch(`${base(this.cfg.url)}/api/frame`, {
            method: "POST",
            headers: this.headers({ "content-type": "image/jpeg" }),
            body: blob,
          })
            .catch(() => undefined)
            .finally(() => {
              this.frameInflight = false;
            });
        },
        "image/jpeg",
        0.6
      );
    }
  }
}

/** Подписка табло на состояние. Возвращает функцию отписки. */
export function connectDisplay(
  url: string,
  token: string,
  onState: (s: RemoteState) => void,
  onStatus: (ok: boolean) => void
): () => void {
  const src = new EventSource(`${base(url)}/api/events?token=${encodeURIComponent(token)}`);
  src.onopen = () => onStatus(true);
  src.onerror = () => onStatus(false);
  src.addEventListener("state", (e) => {
    try {
      onState(JSON.parse((e as MessageEvent).data) as RemoteState);
      onStatus(true);
    } catch {
      /* ignore */
    }
  });
  return () => src.close();
}

export const frameUrl = (url: string, token: string, t: number) =>
  `${base(url)}/api/frame?token=${encodeURIComponent(token)}&t=${t}`;
