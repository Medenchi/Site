/** Равномерное случайное целое [0, n) на основе crypto.getRandomValues (без смещения). */
export function randInt(n: number): number {
  if (n <= 1) return 0;
  const buf = new Uint32Array(1);
  const limit = Math.floor(0x100000000 / n) * n;
  let x: number;
  do {
    crypto.getRandomValues(buf);
    x = buf[0];
  } while (x >= limit);
  return x % n;
}

export function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = randInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export interface SpinStep {
  /** Время шага от начала розыгрыша, мс. */
  at: number;
  id: number;
  /** Прогресс 0..1. */
  p: number;
}

export interface SpinPlan {
  steps: SpinStep[];
  winnerId: number;
  /** Когда включить фазу «напряжение». */
  tensionAt: number;
  /** Когда объявить результат. */
  revealAt: number;
  ids: number[];
}

/**
 * Строит план розыгрыша. Победитель выбирается РАВНОМЕРНО СЛУЧАЙНО из переданного
 * списка и не зависит ни от порядка, ни от номеров, ни от положения. Порядок обхода
 * подсветки — случайная перестановка, а последняя подсвеченная рамка — победитель.
 */
export function buildPlan(ids: number[], durationMs: number): SpinPlan {
  const n = ids.length;
  const perm = shuffle(ids);
  const w = randInt(n);
  const winnerId = perm[w];

  const tensionTotal = Math.min(3800, durationMs * 0.42);
  const fastMs = Math.max(900, durationMs - tensionTotal);
  const slow = [0.2, 0.26, 0.33].map((f) => f * tensionTotal);
  const hold = 0.21 * tensionTotal;

  const times: { at: number; p: number }[] = [];
  let t = 0;
  while (t < fastMs) {
    const p = t / fastMs;
    times.push({ at: t, p: p * 0.8 });
    t += 42 + (400 - 42) * Math.pow(p, 2.3);
  }
  const tensionAt = t;
  let acc = t;
  for (let i = 0; i < slow.length; i++) {
    times.push({ at: acc, p: 0.82 + i * 0.06 });
    acc += slow[i];
  }
  // последний шаг — победитель; после него — пауза-«зависание»
  times.push({ at: acc, p: 1 });
  const revealAt = acc + hold;

  const S = times.length;
  const steps: SpinStep[] = times.map((tm, k) => ({
    at: tm.at,
    p: tm.p,
    id: perm[(((w - (S - 1 - k)) % n) + n) % n],
  }));

  return { steps, winnerId, tensionAt, revealAt, ids: perm };
}
