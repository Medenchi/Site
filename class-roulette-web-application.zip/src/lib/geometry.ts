/** Прямоугольник в нормализованных координатах кадра (0..1). */
export interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Кандидат, найденный детекторами в одном проходе. */
export interface Candidate {
  box: Box;
  score: number;
  kind: "pose" | "face" | "both";
}

export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export const area = (b: Box) => Math.max(0, b.w) * Math.max(0, b.h);

export function interArea(a: Box, b: Box): number {
  const x0 = Math.max(a.x, b.x);
  const y0 = Math.max(a.y, b.y);
  const x1 = Math.min(a.x + a.w, b.x + b.w);
  const y1 = Math.min(a.y + a.h, b.y + b.h);
  return Math.max(0, x1 - x0) * Math.max(0, y1 - y0);
}

export function iou(a: Box, b: Box): number {
  const i = interArea(a, b);
  const u = area(a) + area(b) - i;
  return u > 0 ? i / u : 0;
}

/** Доля пересечения относительно меньшего из двух прямоугольников. */
export function overlapMin(a: Box, b: Box): number {
  const m = Math.min(area(a), area(b));
  return m > 0 ? interArea(a, b) / m : 0;
}

export const center = (b: Box) => ({ x: b.x + b.w / 2, y: b.y + b.h / 2 });

/** Расстояние между центрами, нормированное на размеры рамок. */
export function centerDist(a: Box, b: Box): number {
  const ca = center(a);
  const cb = center(b);
  const dx = (ca.x - cb.x) / Math.max(a.w, b.w, 1e-4);
  const dy = (ca.y - cb.y) / Math.max(a.h, b.h, 1e-4);
  return Math.hypot(dx, dy);
}

export function unionBox(a: Box, b: Box): Box {
  const x0 = Math.min(a.x, b.x);
  const y0 = Math.min(a.y, b.y);
  const x1 = Math.max(a.x + a.w, b.x + b.w);
  const y1 = Math.max(a.y + a.h, b.y + b.h);
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

/** Ограничить рамку пределами кадра с минимальным размером. */
export function clampBox(b: Box, minSize = 0.03): Box {
  const w = clamp(b.w, minSize, 1);
  const h = clamp(b.h, minSize, 1);
  return { x: clamp(b.x, 0, 1 - w), y: clamp(b.y, 0, 1 - h), w, h };
}

export function pointInBox(px: number, py: number, b: Box, pad = 0): boolean {
  return px >= b.x - pad && px <= b.x + b.w + pad && py >= b.y - pad && py <= b.y + b.h + pad;
}

export const FULL_BOX: Box = { x: 0, y: 0, w: 1, h: 1 };
