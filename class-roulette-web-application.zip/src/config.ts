/**
 * Глобальные флаги и пути.
 *
 * Серверный режим («камера на одном устройстве — показ на доске на другом»)
 * по умолчанию ВЫКЛЮЧЕН. Чтобы включить, соберите проект с переменной:
 *   VITE_REMOTE=1 npm run build
 * (подробности — в README.md, раздел «Серверный режим»).
 */
export const FEATURES = {
  /** Серверный режим: трансляция состояния игры на экран-«табло». */
  remote: import.meta.env.VITE_REMOTE === "1",
  /** Передавать ещё и сжатый видеопоток (по умолчанию нет — приватность). */
  remoteVideo: import.meta.env.VITE_REMOTE_VIDEO === "1",
};

/** Адрес сервера для серверного режима. Пусто = тот же origin. */
export const REMOTE_URL: string = (import.meta.env.VITE_REMOTE_URL as string | undefined) ?? "";

const BASE = import.meta.env.BASE_URL || "/";


/** Локальные ресурсы MediaPipe (лежат в public/) и запасные CDN-адреса. */
export const ASSETS = {
  wasmLocal: `${BASE}wasm`,
  // версия закреплена — должна совпадать с установленным @mediapipe/tasks-vision
  wasmCdn: "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.2.2/wasm",
  faceLocal: `${BASE}models/blaze_face_short_range.tflite`,
  faceCdn:
    "https://storage.googleapis.com/mediapipe-models/face_detector/blaze_face_short_range/float16/1/blaze_face_short_range.tflite",
  poseLocal: `${BASE}models/pose_landmarker_lite.task`,
  poseCdn:
    "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",
};
