import { useEffect, useMemo, useRef, useState } from "react";
import { CameraGate } from "./components/CameraGate";
import { ControlBar } from "./components/ControlBar";
import { DisplayView } from "./components/DisplayView";
import { Header } from "./components/Header";
import { LiveStage } from "./components/LiveStage";
import { SettingsDialog } from "./components/SettingsDialog";
import { HistoryCard, ParticipantsCard } from "./components/SidePanel";
import { CalibrationBar, CamLostBanner, EditToolbar, WinnerBanner } from "./components/StageOverlays";
import { FEATURES } from "./config";
import { useCamera } from "./hooks/useCamera";
import { useDetection } from "./hooks/useDetection";
import { useAutoScale, useFullscreen, useGameSnapshot, useWakeLock } from "./hooks/useShell";
import { sfx } from "./lib/audio";
import { BoxEditor, Tool } from "./lib/editor";
import { Game } from "./lib/game";
import { RemoteHost, RemoteLinkStatus } from "./lib/remote";
import { useSettings } from "./lib/settings";

export default function App() {
  useAutoScale();
  const isDisplay = FEATURES.remote && new URLSearchParams(location.search).get("role") === "display";
  return isDisplay ? <DisplayView /> : <MainApp />;
}

function MainApp() {
  const [game] = useState(() => new Game());
  const [editor] = useState(() => new BoxEditor(game));
  const [settings, update] = useSettings();
  const snap = useGameSnapshot(game);
  const videoRef = useRef<HTMLVideoElement>(null);
  const cam = useCamera(videoRef, settings.deviceId);
  const [mode, setMode] = useState<"calibrate" | "play">("calibrate");
  const [tool, setTool] = useState<Tool>("select");
  const [autoDetect, setAutoDetect] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const { fs, toggle: toggleFs } = useFullscreen();
  const remote = useMemo(() => (FEATURES.remote ? new RemoteHost() : null), []);
  const [remoteStatus, setRemoteStatus] = useState<RemoteLinkStatus>("off");
  useWakeLock();

  // --- синхронизация настроек с игрой (простые присваивания) ---
  game.excludeWinners = settings.excludeWinners;
  game.durationMs = settings.durationSec * 1000;
  game.mirror = settings.mirror;
  game.tracker.holdMs = settings.holdSec * 1000;
  sfx.enabled = settings.sound;

  const showStage = cam.status === "live" || cam.status === "reconnecting";
  const live = cam.status === "live";
  const busy = snap.phase === "spinning" || snap.phase === "tension";
  const calibrating = mode === "calibrate";

  const det = useDetection({
    game,
    videoRef,
    live,
    enabled: autoDetect,
    accuracy: settings.accuracy,
    sensitivity: settings.sensitivity,
  });

  // звуки по событиям рулетки
  useEffect(() => {
    game.onEvent = (e) => {
      if (e.type === "start") sfx.start();
      else if (e.type === "tick") sfx.tick(e.p);
      else if (e.type === "tension") sfx.startHeartbeat();
      else if (e.type === "reveal") sfx.reveal();
    };
    editor.onToolDone = () => setTool("select");
    return () => {
      game.onEvent = undefined;
      sfx.stopHeartbeat();
    };
  }, [game, editor]);

  // после первого запуска камеры — калибровка
  const calibratedOnce = useRef(false);
  useEffect(() => {
    if (cam.status === "live" && !calibratedOnce.current) {
      calibratedOnce.current = true;
      setMode("calibrate");
    }
  }, [cam.status]);

  // смена камеры в настройках
  const prevDevice = useRef(settings.deviceId);
  useEffect(() => {
    if (prevDevice.current !== settings.deviceId) {
      prevDevice.current = settings.deviceId;
      if (cam.status === "live" || cam.status === "reconnecting") void cam.start(true);
    }
  }, [settings.deviceId, cam]);

  // серверный режим (по умолчанию выключен)
  useEffect(() => {
    if (!remote) return;
    remote.onStatus = setRemoteStatus;
    remote.configure(settings.remote);
  }, [remote, settings.remote]);

  const spin = () => {
    sfx.unlock();
    game.spin();
  };
  const reset = () => {
    sfx.unlock();
    sfx.stopHeartbeat();
    game.reset();
  };
  const canSpin = !calibrating && !busy && snap.eligible > 0;

  // горячие клавиши (для ПК)
  const keyRef = useRef({ canSpin, spin });
  keyRef.current = { canSpin, spin };
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && ["BUTTON", "INPUT", "SELECT", "TEXTAREA"].includes(t.tagName)) return;
      if (e.code === "Space" || e.code === "Enter") {
        e.preventDefault();
        if (keyRef.current.canSpin) keyRef.current.spin();
      } else if (e.code === "Escape") {
        game.select(null);
        setTool("select");
      } else if (e.code === "Delete" || e.code === "Backspace") {
        if (game.selectedId !== null) game.removeParticipant(game.selectedId);
      } else if (e.code === "KeyF") {
        toggleFs();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [game, toggleFs]);

  const overlay = (
    <>
      {!showStage && <CameraGate status={cam.status} error={cam.error} onStart={() => void cam.start()} />}
      {cam.status === "reconnecting" && (
        <CamLostBanner message={cam.error ?? "Переподключаем камеру…"} onRetry={() => void cam.start(true)} />
      )}
      {live && calibrating && (
        <CalibrationBar
          settings={settings}
          update={update}
          game={game}
          autoDetect={autoDetect}
          setAutoDetect={setAutoDetect}
          hasPeople={snap.total > 0}
          onDone={() => {
            setMode("play");
            setTool("select");
            game.select(null);
          }}
        />
      )}
      {showStage && !busy && (
        <EditToolbar snap={snap} game={game} tool={tool} setTool={setTool} autoDetect={autoDetect} setAutoDetect={setAutoDetect} />
      )}
      {det.status === "error" && live && (
        <div className="iron absolute bottom-20 right-3 z-10 max-w-[30rem] px-5 py-3 text-[1rem] leading-snug text-[#ffb3a8]">
          Не удалось загрузить модели распознавания (при первом запуске нужен интернет либо файлы в public/models).
          Рамки можно расставить вручную: «＋ Рамка».
        </div>
      )}
      <WinnerBanner snap={snap} />
    </>
  );

  return (
    <div className="wood-bg flex h-full flex-col gap-3 p-3">
      <Header
        snap={snap}
        cam={cam.status}
        det={live ? det.status : undefined}
        stats={det.stats}
        remote={remoteStatus}
        fs={fs}
        calibrating={calibrating && live}
        onCalibrate={() => (live || snap.total > 0) && setMode(calibrating ? "play" : "calibrate")}
        onFullscreen={toggleFs}
        onSettings={() => setShowSettings(true)}
      />
      <div className="flex min-h-0 flex-1 gap-3">
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="wood-panel flex min-h-0 flex-1 p-3">
            <div className="iron relative min-h-0 min-w-0 flex-1 overflow-hidden">
              <LiveStage
                game={game}
                editor={editor}
                tool={tool}
                videoRef={videoRef}
                size={cam.size}
                live={showStage}
                remote={remote}
                overlay={overlay}
              />
            </div>
          </div>
          <ControlBar
            snap={snap}
            calibrating={calibrating}
            live={showStage}
            durationSec={settings.durationSec}
            onDuration={(s) => update({ durationSec: s })}
            onSpin={spin}
            onReset={reset}
          />
        </div>
        <aside className="flex w-[27rem] shrink-0 flex-col gap-3">
          <ParticipantsCard snap={snap} game={game} />
          <HistoryCard history={snap.history} onClear={() => game.clearHistory()} />
        </aside>
      </div>
      {showSettings && (
        <SettingsDialog
          settings={settings}
          update={update}
          devices={cam.devices}
          remoteStatus={remoteStatus}
          onClose={() => setShowSettings(false)}
          onRestartCamera={() => void cam.start(true)}
        />
      )}
    </div>
  );
}
