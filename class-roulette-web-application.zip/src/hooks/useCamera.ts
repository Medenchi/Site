import { RefObject, useCallback, useEffect, useRef, useState } from "react";

export type CamStatus = "off" | "starting" | "live" | "reconnecting" | "error";

function describe(e: unknown): { msg: string; fatal: boolean } {
  const name = (e as { name?: string })?.name ?? "";
  switch (name) {
    case "NotAllowedError":
    case "SecurityError":
      return {
        msg: "Доступ к камере запрещён. Разрешите камеру в настройках браузера (значок замка рядом с адресом) и нажмите «Повторить».",
        fatal: true,
      };
    case "NotFoundError":
    case "DevicesNotFoundError":
      return { msg: "Камера не найдена. Подключите камеру — приложение подключится автоматически.", fatal: false };
    case "NotReadableError":
    case "TrackStartError":
      return { msg: "Камера занята другой программой. Закройте её — подключение повторится само.", fatal: false };
    case "OverconstrainedError":
      return { msg: "Выбранная камера недоступна, пробуем другую…", fatal: false };
    default:
      return { msg: `Не удалось включить камеру${name ? ` (${name})` : ""}.`, fatal: false };
  }
}

/** Камера: запуск, выбор устройства, автопереподключение, сторожевой таймер. */
export function useCamera(videoRef: RefObject<HTMLVideoElement | null>, deviceId: string) {
  const [status, setStatus] = useState<CamStatus>("off");
  const [error, setError] = useState<string | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [size, setSize] = useState<{ w: number; h: number } | null>(null);

  const streamRef = useRef<MediaStream | null>(null);
  const wantRef = useRef(false);
  const timerRef = useRef<number | null>(null);
  const devRef = useRef(deviceId);
  const startRef = useRef<(retry?: boolean) => Promise<void>>(async () => {});
  devRef.current = deviceId;

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => {
      t.onended = null;
      t.stop();
    });
    streamRef.current = null;
  }, []);

  const clearTimer = () => {
    if (timerRef.current !== null) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const refreshDevices = useCallback(async () => {
    try {
      const list = await navigator.mediaDevices.enumerateDevices();
      setDevices(list.filter((d) => d.kind === "videoinput"));
    } catch {
      /* ignore */
    }
  }, []);

  const start = useCallback(
    async (retry = false) => {
      clearTimer();
      wantRef.current = true;
      if (!navigator.mediaDevices?.getUserMedia) {
        setError(
          "Камера недоступна: страница должна открываться по HTTPS или с адреса localhost (в браузере с поддержкой getUserMedia)."
        );
        setStatus("error");
        return;
      }
      setStatus(retry ? "reconnecting" : "starting");
      stopStream();
      const attempt = async (useDevice: boolean) =>
        navigator.mediaDevices.getUserMedia({
          video: {
            ...(useDevice && devRef.current ? { deviceId: { exact: devRef.current } } : {}),
            width: { ideal: 1920 },
            height: { ideal: 1080 },
            frameRate: { ideal: 30 },
          },
          audio: false,
        });
      try {
        let stream: MediaStream;
        try {
          stream = await attempt(true);
        } catch (e) {
          if ((e as { name?: string }).name === "OverconstrainedError") stream = await attempt(false);
          else throw e;
        }
        if (!wantRef.current) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const v = videoRef.current;
        if (v) {
          v.srcObject = stream;
          await v.play().catch(() => undefined);
        }
        const track = stream.getVideoTracks()[0];
        track.onended = () => {
          if (!wantRef.current) return;
          setStatus("reconnecting");
          setError("Связь с камерой потеряна. Пробуем подключиться снова…");
          timerRef.current = window.setTimeout(() => void startRef.current(true), 1500);
        };
        const st = track.getSettings();
        if (st.width && st.height) setSize({ w: st.width, h: st.height });
        setError(null);
        setStatus("live");
        void refreshDevices();
      } catch (e) {
        const d = describe(e);
        setError(d.msg);
        if (d.fatal || !wantRef.current) {
          setStatus("error");
        } else {
          setStatus("reconnecting");
          timerRef.current = window.setTimeout(() => void startRef.current(true), 3000);
        }
      }
    },
    [refreshDevices, stopStream, videoRef]
  );
  startRef.current = start;

  const stop = useCallback(() => {
    wantRef.current = false;
    clearTimer();
    stopStream();
    if (videoRef.current) videoRef.current.srcObject = null;
    setStatus("off");
    setError(null);
  }, [stopStream, videoRef]);

  // реальный размер видео после загрузки метаданных
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const on = () => {
      if (v.videoWidth) setSize({ w: v.videoWidth, h: v.videoHeight });
    };
    v.addEventListener("loadedmetadata", on);
    v.addEventListener("resize", on);
    return () => {
      v.removeEventListener("loadedmetadata", on);
      v.removeEventListener("resize", on);
    };
  }, [videoRef]);

  // подключили/отключили камеру — пробуем заново
  useEffect(() => {
    const onChange = () => {
      void refreshDevices();
      if (wantRef.current && (status === "error" || status === "reconnecting")) void startRef.current(true);
    };
    navigator.mediaDevices?.addEventListener?.("devicechange", onChange);
    return () => navigator.mediaDevices?.removeEventListener?.("devicechange", onChange);
  }, [refreshDevices, status]);

  // сторожевой таймер: кадры перестали идти — переподключаемся
  useEffect(() => {
    if (status !== "live") return;
    let last = -1;
    let stuck = 0;
    const id = window.setInterval(() => {
      const v = videoRef.current;
      if (!v || document.hidden) return;
      if (v.currentTime === last) stuck++;
      else stuck = 0;
      last = v.currentTime;
      if (stuck >= 3) {
        stuck = 0;
        setError("Видеопоток остановился. Переподключаемся…");
        void startRef.current(true);
      }
    }, 2000);
    return () => clearInterval(id);
  }, [status, videoRef]);

  useEffect(
    () => () => {
      wantRef.current = false;
      clearTimer();
      stopStream();
    },
    [stopStream]
  );

  return { status, error, devices, size, start, stop };
}
