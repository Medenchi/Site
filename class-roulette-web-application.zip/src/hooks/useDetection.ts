import { RefObject, useEffect, useRef, useState } from "react";
import { detector, DetectorStatus } from "../lib/detector";
import type { Game } from "../lib/game";
import { Box, FULL_BOX } from "../lib/geometry";

const REGIONS_HIGH: Box[] = [FULL_BOX, { x: 0, y: 0, w: 0.58, h: 1 }, { x: 0.42, y: 0, w: 0.58, h: 1 }];

interface Opts {
  game: Game;
  videoRef: RefObject<HTMLVideoElement | null>;
  /** Камера включена. */
  live: boolean;
  /** Детекция разрешена (не заморожена пользователем). */
  enabled: boolean;
  accuracy: "fast" | "high";
  sensitivity: number;
}

/**
 * Цикл детекции. Работает с адаптивной скважностью: после каждого прохода
 * пауза не меньше времени самого прохода — основной поток остаётся свободным
 * для интерфейса и анимации. Во время розыгрыша детекция приостанавливается.
 */
export function useDetection({ game, videoRef, live, enabled, accuracy, sensitivity }: Opts) {
  const [status, setStatus] = useState<DetectorStatus>(detector.status);
  const [stats, setStats] = useState({ fps: 0, ms: 0, delegate: detector.delegate });
  const optRef = useRef({ enabled, accuracy });
  optRef.current = { enabled, accuracy };

  useEffect(() => {
    if (status === "ready") detector.setSensitivity(sensitivity);
  }, [sensitivity, status]);

  useEffect(() => {
    if (!live) return;
    let stop = false;
    let timer = 0;
    let idx = 0;
    let frames = 0;
    let costSum = 0;
    let lastReport = performance.now();

    setStatus("loading");
    detector
      .init()
      .then(() => {
        if (stop) return;
        setStatus("ready");
        detector.setSensitivity(sensitivity);
        loop();
      })
      .catch(() => {
        if (!stop) setStatus("error");
      });

    function loop() {
      if (stop) return;
      const t0 = performance.now();
      const v = videoRef.current;
      const o = optRef.current;
      let ran = false;
      if (v && v.readyState >= 2 && v.videoWidth && o.enabled && !document.hidden && !game.busy) {
        const regions = o.accuracy === "high" ? REGIONS_HIGH : [FULL_BOX];
        const region = regions[idx++ % regions.length];
        try {
          const cands = detector.detect(v, region);
          game.ingest(cands, region, performance.now());
          ran = true;
        } catch (e) {
          console.warn("detect failed", e);
        }
      }
      const t1 = performance.now();
      if (ran) {
        frames++;
        costSum += t1 - t0;
      }
      if (t1 - lastReport > 1000) {
        const dtS = (t1 - lastReport) / 1000;
        setStats({
          fps: Math.round(frames / dtS),
          ms: frames ? Math.round(costSum / frames) : 0,
          delegate: detector.delegate,
        });
        frames = 0;
        costSum = 0;
        lastReport = t1;
      }
      const cost = t1 - t0;
      timer = window.setTimeout(loop, ran ? Math.max(25, cost * 0.9, 66 - cost) : 150);
    }

    return () => {
      stop = true;
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [live, game, videoRef]);

  return { status, stats, error: detector.error };
}
