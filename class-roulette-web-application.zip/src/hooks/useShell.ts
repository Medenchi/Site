import { useCallback, useEffect, useState, useSyncExternalStore } from "react";
import type { Game } from "../lib/game";

/** Автомасштабирование интерфейса под разрешение доски (rem = пропорционально экрану). */
export function useAutoScale() {
  useEffect(() => {
    const apply = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const landscape = w / h >= 1.2;
      const k = landscape ? Math.min(w / 1920, h / 1080) : w / 1100;
      const px = 16 * Math.min(3, Math.max(0.5, k));
      document.documentElement.style.fontSize = `${px}px`;
    };
    apply();
    window.addEventListener("resize", apply);
    return () => window.removeEventListener("resize", apply);
  }, []);
}

export function useFullscreen() {
  const [fs, setFs] = useState(!!document.fullscreenElement);
  useEffect(() => {
    const on = () => setFs(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", on);
    return () => document.removeEventListener("fullscreenchange", on);
  }, []);
  const toggle = useCallback(() => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen({ navigationUI: "hide" }).catch(() => undefined);
  }, []);
  return { fs, toggle };
}

export function useGameSnapshot(game: Game) {
  return useSyncExternalStore(game.subscribe, game.getSnapshot);
}

/** Не даём экрану доски засыпать, пока открыто приложение. */
export function useWakeLock() {
  useEffect(() => {
    let lock: { release: () => Promise<void> } | null = null;
    const req = async () => {
      try {
        const nav = navigator as unknown as { wakeLock?: { request: (t: string) => Promise<{ release: () => Promise<void> }> } };
        lock = (await nav.wakeLock?.request("screen")) ?? null;
      } catch {
        /* ignore */
      }
    };
    void req();
    const vis = () => {
      if (document.visibilityState === "visible") void req();
    };
    document.addEventListener("visibilitychange", vis);
    return () => {
      document.removeEventListener("visibilitychange", vis);
      void lock?.release();
    };
  }, []);
}
