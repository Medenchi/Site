import { ReactNode, useEffect, useRef, useState } from "react";
import type { PointerInfo } from "../lib/editor";
import { StageRenderer } from "../lib/renderer";
import type { RModel } from "../lib/types";

export type PointerType = "down" | "move" | "up" | "cancel";

interface Props {
  aspect: number;
  getModel: (now: number) => RModel;
  onFrame?: (dt: number, now: number) => void;
  onPointer?: (type: PointerType, p: PointerInfo, e: React.PointerEvent<HTMLCanvasElement>) => boolean | void;
  cursor?: string;
  /** Фон под холстом (видео / картинка) — вписывается в рамку с нужным соотношением сторон. */
  children?: ReactNode;
  /** Слой поверх всей области сцены. */
  overlay?: ReactNode;
}

const rootU = () => (parseFloat(document.documentElement.style.fontSize) || 16) / 16;

/**
 * Область сцены: вписывает кадр нужного соотношения сторон, держит ОДИН canvas
 * и крутит цикл requestAnimationFrame.
 */
export function StageSurface({ aspect, getModel, onFrame, onPointer, cursor, children, overlay }: Props) {
  const wrap = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendRef = useRef<StageRenderer | null>(null);
  const [fit, setFit] = useState({ w: 0, h: 0 });
  const fitRef = useRef(fit);
  fitRef.current = fit;
  const cb = useRef({ getModel, onFrame, onPointer });
  cb.current = { getModel, onFrame, onPointer };

  useEffect(() => {
    const el = wrap.current!;
    const calc = () => {
      const cw = el.clientWidth;
      const ch = el.clientHeight;
      const w = Math.floor(Math.min(cw, ch * aspect));
      setFit({ w, h: Math.floor(w / aspect) });
    };
    calc();
    const ro = new ResizeObserver(calc);
    ro.observe(el);
    return () => ro.disconnect();
  }, [aspect]);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const r = new StageRenderer(canvas);
    rendRef.current = r;
    let raf = 0;
    let last = performance.now();
    let lastKey = "";
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const f = fitRef.current;
      const u = rootU();
      const dpr = Math.min(window.devicePixelRatio || 1, 2, 2560 / Math.max(1, f.w));
      const key = `${f.w}x${f.h}@${dpr.toFixed(2)}:${u.toFixed(3)}`;
      if (key !== lastKey) {
        lastKey = key;
        r.resize(f.w, f.h, dpr, u);
      }
      cb.current.onFrame?.(dt, now);
      r.draw(cb.current.getModel(now), now);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      rendRef.current = null;
    };
  }, []);

  const info = (e: React.PointerEvent<HTMLCanvasElement>): PointerInfo => {
    const rect = e.currentTarget.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) / rect.width,
      y: (e.clientY - rect.top) / rect.height,
      w: rect.width,
      h: rect.height,
      u: rootU(),
    };
  };

  return (
    <div ref={wrap} className="relative flex h-full min-h-0 w-full min-w-0 items-center justify-center">
      <div className="relative overflow-hidden bg-ebony" style={{ width: fit.w, height: fit.h }}>
        {children}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 h-full w-full"
          style={{ cursor: cursor ?? "default" }}
          onPointerDown={(e) => {
            if (!cb.current.onPointer) return;
            const captured = cb.current.onPointer("down", info(e), e);
            if (captured) e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => cb.current.onPointer?.("move", info(e), e)}
          onPointerUp={(e) => cb.current.onPointer?.("up", info(e), e)}
          onPointerCancel={(e) => cb.current.onPointer?.("cancel", info(e), e)}
        />
      </div>
      {overlay}
    </div>
  );
}
