import type { CamStatus } from "../hooks/useCamera";
import type { DetectorStatus } from "../lib/detector";
import type { RemoteLinkStatus } from "../lib/remote";
import type { Snapshot } from "../lib/types";

interface Props {
  snap: Pick<Snapshot, "total" | "eligible" | "round">;
  cam?: CamStatus;
  det?: DetectorStatus;
  stats?: { fps: number; ms: number; delegate: string };
  remote?: RemoteLinkStatus;
  fs?: boolean;
  calibrating?: boolean;
  onCalibrate?: () => void;
  onFullscreen?: () => void;
  onSettings?: () => void;
  displayNote?: string;
}

function Emblem() {
  return (
    <svg viewBox="0 0 64 64" className="h-[3.3rem] w-[3.3rem] shrink-0">
      <defs>
        <radialGradient id="eg" cx="50%" cy="40%" r="70%">
          <stop offset="0" stopColor="#6a4020" />
          <stop offset="1" stopColor="#1e1008" />
        </radialGradient>
      </defs>
      <circle cx="32" cy="32" r="29" fill="url(#eg)" stroke="#d9b26a" strokeWidth="3" />
      <circle cx="32" cy="32" r="19" fill="none" stroke="#d9b26a" strokeWidth="2" strokeDasharray="3 4" />
      <circle cx="32" cy="32" r="9" fill="none" stroke="#e0221a" strokeWidth="3" />
      <path d="M32 2v14M32 48v14M2 32h14M48 32h14" stroke="#f6dc9a" strokeWidth="3" />
      <circle cx="32" cy="32" r="2.6" fill="#e0221a" />
    </svg>
  );
}

function Dot({ color, label, pulse }: { color: string; label: string; pulse?: boolean }) {
  return (
    <span className="flex items-center gap-2 text-[0.95rem] uppercase tracking-wider text-[#cdb88f]">
      <span
        className={`h-3 w-3 rounded-full ${pulse ? "animate-blink" : ""}`}
        style={{ background: color, boxShadow: `0 0 0.6rem ${color}` }}
      />
      {label}
    </span>
  );
}

export function Header({
  snap,
  cam,
  det,
  stats,
  remote,
  fs,
  calibrating,
  onCalibrate,
  onFullscreen,
  onSettings,
  displayNote,
}: Props) {
  const camDot =
    cam === "live"
      ? { c: "#4ade80", l: "камера" }
      : cam === "starting" || cam === "reconnecting"
        ? { c: "#fbbf24", l: cam === "starting" ? "запуск" : "переподключение" }
        : cam === "error"
          ? { c: "#ef4444", l: "ошибка камеры" }
          : { c: "#6b5a44", l: "камера выкл." };
  const detDot =
    det === "ready"
      ? { c: "#4ade80", l: `ИИ ${stats?.delegate ?? ""} · ${stats?.fps ?? 0} к/с · ${stats?.ms ?? 0} мс` }
      : det === "loading"
        ? { c: "#fbbf24", l: "загрузка моделей" }
        : det === "error"
          ? { c: "#ef4444", l: "модели не загружены" }
          : null;

  return (
    <header className="wood-panel flex h-[5.2rem] shrink-0 items-center gap-6 px-5">
      <div className="flex items-center gap-4">
        <Emblem />
        <div className="leading-none">
          <div className="engrave font-display text-[2.1rem] tracking-[0.14em] text-brass-light">CLASS ROULETTE</div>
          <div className="mt-1 text-[0.95rem] uppercase tracking-[0.32em] text-[#c9ae7c]">
            {displayNote ?? "случайный выбор ученика"}
          </div>
        </div>
      </div>

      <div className="mx-auto flex items-stretch gap-3">
        <div className="iron flex items-center gap-3 px-5">
          <div className="text-right text-[0.85rem] uppercase leading-tight tracking-widest text-[#b9a27a]">
            в кадре
            <br />
            учеников
          </div>
          <div className="font-display text-[3rem] leading-none text-brass-light tabular-nums">{snap.total}</div>
        </div>
        <div className="iron flex items-center gap-3 px-5">
          <div className="text-right text-[0.85rem] uppercase leading-tight tracking-widest text-[#b9a27a]">
            в игре
            <br />
            раунд {snap.round}
          </div>
          <div className="font-display text-[3rem] leading-none text-[#ff6a4a] tabular-nums">{snap.eligible}</div>
        </div>
      </div>

      <div className="flex flex-col items-start gap-0.5">
        {cam && <Dot color={camDot.c} label={camDot.l} pulse={cam === "starting" || cam === "reconnecting"} />}
        {detDot && <Dot color={detDot.c} label={detDot.l} pulse={det === "loading"} />}
        {remote && remote !== "off" && (
          <Dot color={remote === "ok" ? "#60a5fa" : "#ef4444"} label={remote === "ok" ? "табло подключено" : "нет связи с сервером"} />
        )}
      </div>

      <div className="flex items-center gap-3">
        {onCalibrate && (
          <button className={`btn ${calibrating ? "btn-on" : ""}`} onClick={onCalibrate}>
            ⌖ Калибровка
          </button>
        )}
        {onFullscreen && (
          <button className="btn btn-icon" onClick={onFullscreen} title="Полный экран">
            {fs ? "⤡" : "⤢"}
            <span className="max-xl:hidden">{fs ? "Окно" : "Экран"}</span>
          </button>
        )}
        {onSettings && (
          <button className="btn btn-icon" onClick={onSettings} title="Настройки">
            ⚙<span className="max-xl:hidden">Настройки</span>
          </button>
        )}
      </div>
    </header>
  );
}
