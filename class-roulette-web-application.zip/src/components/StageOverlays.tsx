import type { Game } from "../lib/game";
import type { Tool } from "../lib/editor";
import type { Settings } from "../lib/settings";
import type { Snapshot } from "../lib/types";
import { Segmented } from "./ui";

/** Панель калибровки поверх камеры. */
export function CalibrationBar({
  settings,
  update,
  game,
  autoDetect,
  setAutoDetect,
  onDone,
  hasPeople,
}: {
  settings: Settings;
  update: (p: Partial<Settings>) => void;
  game: Game;
  autoDetect: boolean;
  setAutoDetect: (v: boolean) => void;
  onDone: () => void;
  hasPeople: boolean;
}) {
  return (
    <div className="iron rivets animate-fadein absolute left-3 right-3 top-3 z-10 flex flex-wrap items-center gap-x-6 gap-y-3 px-6 py-4">
      <div className="min-w-[16rem] flex-1">
        <div className="font-display text-[1.6rem] tracking-wider text-brass-light">КАЛИБРОВКА</div>
        <div className="text-[1.05rem] leading-snug text-[#d8c39a]">
          Проверьте рамки: <b>перетащите</b> рамку, потяните за <b>угол</b>, добавьте недостающих кнопкой «+ Рамка»,
          лишних удалите. Подвинутая вручную рамка закрепляется (🔒).
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-[0.95rem] uppercase tracking-wider text-[#b9a27a]">Чувствит.</span>
        <input
          type="range"
          min={0}
          max={1}
          step={0.05}
          value={settings.sensitivity}
          onChange={(e) => update({ sensitivity: Number(e.target.value) })}
          className="w-36"
        />
      </div>
      <Segmented
        value={settings.accuracy}
        onChange={(v) => update({ accuracy: v })}
        options={[
          { value: "fast", label: "Быстро" },
          { value: "high", label: "Точно" },
        ]}
      />
      <button className={`btn btn-sm ${settings.mirror ? "btn-on" : ""}`} onClick={() => update({ mirror: !settings.mirror })}>
        ⇋ Зеркало
      </button>
      <button className={`btn btn-sm ${autoDetect ? "btn-on" : ""}`} onClick={() => setAutoDetect(!autoDetect)}>
        {autoDetect ? "Автопоиск: вкл" : "Автопоиск: выкл"}
      </button>
      <button className="btn btn-sm" onClick={() => game.lockAll(true)}>
        🔒 Закрепить все
      </button>
      <button className="btn btn-sm" onClick={() => game.lockAll(false)}>
        Следить за всеми
      </button>
      <button className="btn btn-sm btn-danger" onClick={() => game.clearAll()}>
        ✕ Очистить
      </button>
      <button className="btn btn-gold !min-h-[3.6rem] !px-8 !text-[1.35rem]" onClick={onDone} disabled={!hasPeople}>
        ✔ Готово — к игре
      </button>
    </div>
  );
}

/** Нижняя панель правки рамок. */
export function EditToolbar({
  snap,
  game,
  tool,
  setTool,
  autoDetect,
  setAutoDetect,
}: {
  snap: Snapshot;
  game: Game;
  tool: Tool;
  setTool: (t: Tool) => void;
  autoDetect: boolean;
  setAutoDetect: (v: boolean) => void;
}) {
  const sel = snap.participants.find((p) => p.id === snap.selectedId);
  return (
    <div className="absolute bottom-3 left-3 z-10 flex flex-wrap items-center gap-2">
      <button className={`btn btn-sm ${tool === "add" ? "btn-gold" : ""}`} onClick={() => setTool(tool === "add" ? "select" : "add")}>
        {tool === "add" ? "Нарисуйте рамку на кадре…" : "＋ Рамка"}
      </button>
      <button
        className={`btn btn-sm ${autoDetect ? "" : "btn-danger"}`}
        onClick={() => setAutoDetect(!autoDetect)}
        title="Пауза автоматического поиска людей"
      >
        {autoDetect ? "⏸ Пауза поиска" : "▶ Возобновить поиск"}
      </button>
      {sel && (
        <div className="iron animate-fadein flex items-center gap-2 px-3 py-2">
          <span className="font-display text-[1.3rem] text-brass-light">№{sel.num}</span>
          <button className="btn btn-sm" onClick={() => game.toggleLock(sel.id)}>
            {sel.locked ? "🔓 Следить" : "🔒 Закрепить"}
          </button>
          <button className="btn btn-sm" onClick={() => game.setExcluded(sel.id, !sel.excluded)}>
            {sel.excluded ? "Вернуть" : "Исключить"}
          </button>
          <button className="btn btn-sm btn-danger" onClick={() => game.removeParticipant(sel.id)}>
            ✕ Удалить
          </button>
        </div>
      )}
    </div>
  );
}

/** Плашка статуса розыгрыша и объявление результата. */
export function WinnerBanner({ snap }: { snap: Pick<Snapshot, "phase" | "winnerId" | "participants" | "round"> }) {
  const win = snap.participants.find((p) => p.id === snap.winnerId);
  if (snap.phase === "reveal" && win) {
    return (
      <div className="pointer-events-none absolute inset-x-0 top-5 z-10 flex justify-center">
        <div
          key={`${snap.round}-${win.id}`}
          className="animate-slam flex items-center gap-6 rounded-xl border-[0.3rem] border-[#ffd9d2] px-10 py-3 shadow-[0_0_4rem_rgba(255,40,24,0.8)]"
          style={{ background: "linear-gradient(180deg,#ff3a2c,#a80f08)" }}
        >
          <span className="text-[1.6rem] font-bold uppercase tracking-[0.3em] text-[#ffe3dc]">выбран</span>
          <span className="font-display text-[5rem] leading-none text-white" style={{ textShadow: "0 0.25rem 0 #5a0602" }}>
            №{win.num}
          </span>
        </div>
      </div>
    );
  }
  if (snap.phase === "spinning" || snap.phase === "tension") {
    return (
      <div className="pointer-events-none absolute inset-x-0 top-5 z-10 flex justify-center">
        <div
          className={`iron px-8 py-2 font-display text-[2rem] tracking-[0.25em] ${
            snap.phase === "tension" ? "text-[#ff6a4a] animate-blink" : "text-brass-light"
          }`}
        >
          {snap.phase === "tension" ? "РЕШАЕТСЯ…" : "ВЫБИРАЕМ…"}
        </div>
      </div>
    );
  }
  return null;
}

/** Баннер потери связи с камерой. */
export function CamLostBanner({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="iron animate-fadein absolute bottom-3 right-3 z-20 flex max-w-[34rem] items-center gap-4 border-[#a8392d] px-5 py-3">
      <span className="text-[1.1rem] leading-snug text-[#ffb3a8]">{message}</span>
      <button className="btn btn-sm shrink-0" onClick={onRetry}>
        ↻ Сейчас
      </button>
    </div>
  );
}
