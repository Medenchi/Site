import { useEffect, useMemo, useRef, useState } from "react";
import { connectDisplay, frameUrl } from "../lib/remote";
import type { RBox, RemoteState, RModel } from "../lib/types";
import { useFullscreen } from "../hooks/useShell";
import { Header } from "./Header";
import { HistoryCard } from "./SidePanel";
import { StageSurface } from "./StageSurface";
import { WinnerBanner } from "./StageOverlays";

/**
 * Режим «табло» (серверный режим). Только показывает то, что присылает
 * устройство с камерой: рамки, подсветку, результат, историю.
 * Адрес: https://<сервер>/?role=display[&server=URL][&token=XXX]
 */
export function DisplayView() {
  const params = useMemo(() => new URLSearchParams(location.search), []);
  const url = params.get("server") ?? "";
  const token = params.get("token") ?? "";
  const [state, setState] = useState<RemoteState | null>(null);
  const [online, setOnline] = useState(false);
  const latest = useRef<RemoteState | null>(null);
  const disp = useRef(new Map<number, RBox>());
  const lastKey = useRef("");
  const [frame, setFrame] = useState("");
  const { fs, toggle } = useFullscreen();

  useEffect(
    () =>
      connectDisplay(
        url,
        token,
        (s) => {
          latest.current = s;
          // React-состояние обновляем только при смысловых изменениях
          const key = `${s.snapshot.phase}|${s.snapshot.total}|${s.snapshot.eligible}|${s.snapshot.history.length}|${s.snapshot.winnerId}|${s.aspect.toFixed(3)}`;
          if (key !== lastKey.current) {
            lastKey.current = key;
            setState(s);
          }
        },
        setOnline
      ),
    [url, token]
  );

  useEffect(() => {
    if (!state?.hasVideo) {
      setFrame("");
      return;
    }
    const id = window.setInterval(() => {
      const src = frameUrl(url, token, Date.now());
      const img = new Image();
      img.onload = () => setFrame(src);
      img.src = src;
    }, 500);
    return () => clearInterval(id);
  }, [state?.hasVideo, url, token]);

  const getModel = (): RModel => {
    const s = latest.current;
    if (!s) {
      return { boxes: [], phase: "idle", highlightId: null, winnerId: null, selectedId: null, mirror: true, editing: false, draft: null };
    }
    // сглаживаем приходящие ~15 раз/с координаты до плавного движения
    const map = disp.current;
    const ids = new Set<number>();
    const boxes: RBox[] = s.model.boxes.map((b) => {
      ids.add(b.id);
      const d = map.get(b.id);
      const nb = d ? { ...b, x: d.x + (b.x - d.x) * 0.35, y: d.y + (b.y - d.y) * 0.35, w: d.w + (b.w - d.w) * 0.35, h: d.h + (b.h - d.h) * 0.35 } : b;
      map.set(b.id, nb);
      return nb;
    });
    for (const k of map.keys()) if (!ids.has(k)) map.delete(k);
    return { ...s.model, boxes, editing: false };
  };

  const snap = state?.snapshot ?? {
    participants: [],
    phase: "idle" as const,
    winnerId: null,
    selectedId: null,
    history: [],
    round: 1,
    eligible: 0,
    total: 0,
  };

  return (
    <div className="wood-bg flex h-full flex-col gap-3 p-3">
      <Header snap={snap} fs={fs} onFullscreen={toggle} displayNote="табло · режим показа" />
      <div className="flex min-h-0 flex-1 gap-3">
        <div className="wood-panel flex min-h-0 min-w-0 flex-1 p-3">
          <div className="iron relative min-h-0 min-w-0 flex-1 overflow-hidden">
            <StageSurface
              aspect={state?.aspect ?? 16 / 9}
              getModel={getModel}
              overlay={
                <>
                  <WinnerBanner snap={snap} />
                  {!online && (
                    <div className="iron absolute inset-x-0 bottom-6 mx-auto w-fit px-8 py-3 text-[1.4rem] text-[#ffb3a8]">
                      Нет связи с сервером…
                    </div>
                  )}
                  {online && !state && (
                    <div className="iron absolute inset-x-0 bottom-6 mx-auto w-fit px-8 py-3 text-[1.4rem] text-brass-light">
                      Ожидаем данные от устройства с камерой…
                    </div>
                  )}
                </>
              }
            >
              {frame ? (
                <img
                  src={frame}
                  alt=""
                  className="absolute inset-0 h-full w-full"
                  style={{ transform: state?.model.mirror ? "scaleX(-1)" : undefined }}
                />
              ) : (
                <div
                  className="absolute inset-0"
                  style={{
                    backgroundImage:
                      "linear-gradient(rgba(217,178,106,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(217,178,106,0.07) 1px, transparent 1px)",
                    backgroundSize: "4rem 4rem",
                  }}
                />
              )}
            </StageSurface>
          </div>
        </div>
        <aside className="flex w-[27rem] shrink-0 flex-col gap-3">
          <HistoryCard history={snap.history} />
        </aside>
      </div>
    </div>
  );
}
