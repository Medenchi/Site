import { FEATURES } from "../config";
import type { RemoteLinkStatus } from "../lib/remote";
import type { Settings } from "../lib/settings";
import { Field, Segmented, Toggle } from "./ui";

interface Props {
  settings: Settings;
  update: (p: Partial<Settings>) => void;
  devices: MediaDeviceInfo[];
  remoteStatus: RemoteLinkStatus;
  onClose: () => void;
  onRestartCamera: () => void;
}

export function SettingsDialog({ settings, update, devices, remoteStatus, onClose, onRestartCamera }: Props) {
  const r = settings.remote;
  const setRemote = (p: Partial<Settings["remote"]>) => update({ remote: { ...r, ...p } });
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6" onClick={onClose}>
      <div
        className="wood-panel animate-fadein flex max-h-full w-[46rem] max-w-full flex-col p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-[2rem] tracking-wider text-brass-light engrave">НАСТРОЙКИ</h2>
          <button className="btn btn-icon" onClick={onClose}>
            ✕ Закрыть
          </button>
        </div>
        <div className="iron scroll-wood min-h-0 flex-1 divide-y divide-[#3a2814] overflow-y-auto px-5 py-2">
          <Field label={`Длительность рулетки: ${settings.durationSec} с`}>
            <input
              type="range"
              min={3}
              max={20}
              step={1}
              value={settings.durationSec}
              onChange={(e) => update({ durationSec: Number(e.target.value) })}
              className="w-60"
            />
          </Field>
          <Toggle label="Исключать выбранных из следующих раундов" on={settings.excludeWinners} onChange={(v) => update({ excludeWinners: v })} />
          <Toggle label="Звуки" on={settings.sound} onChange={(v) => update({ sound: v })} />
          <Toggle label="Зеркальное отображение камеры" on={settings.mirror} onChange={(v) => update({ mirror: v })} />
          <Field label="Точность поиска" hint="«Точно» анализирует кадр по частям — находит дальних учеников, но нагружает процессор вдвое-втрое сильнее.">
            <Segmented
              value={settings.accuracy}
              onChange={(v) => update({ accuracy: v })}
              options={[
                { value: "fast", label: "Быстро" },
                { value: "high", label: "Точно" },
              ]}
            />
          </Field>
          <Field label="Чувствительность поиска">
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={settings.sensitivity}
              onChange={(e) => update({ sensitivity: Number(e.target.value) })}
              className="w-60"
            />
          </Field>
          <Field label="Держать рамку без обнаружения" hint="Сколько ученик может быть полностью не виден, прежде чем рамка исчезнет. Рамки, добавленные или закреплённые вручную, не исчезают.">
            <Segmented
              value={settings.holdSec}
              onChange={(v) => update({ holdSec: v })}
              options={[
                { value: 15, label: "15 с" },
                { value: 45, label: "45 с" },
                { value: 180, label: "3 мин" },
                { value: 0, label: "всегда" },
              ]}
            />
          </Field>
          <Field label="Камера">
            <div className="flex items-center gap-2">
              <select
                value={settings.deviceId}
                onChange={(e) => {
                  update({ deviceId: e.target.value });
                }}
                className="w-64"
              >
                <option value="">По умолчанию</option>
                {devices.map((d, i) => (
                  <option key={d.deviceId || i} value={d.deviceId}>
                    {d.label || `Камера ${i + 1}`}
                  </option>
                ))}
              </select>
              <button className="btn btn-sm" onClick={onRestartCamera}>
                ↻
              </button>
            </div>
          </Field>

          {FEATURES.remote && (
            <div className="py-3">
              <div className="mb-1 font-display text-[1.3rem] tracking-wider text-brass-light">СЕРВЕРНЫЙ РЕЖИМ</div>
              <p className="mb-2 text-[0.95rem] leading-snug text-[#b9a27a]">
                Отправляет на сервер только координаты рамок и состояние игры. Откройте на доске адрес сервера с
                параметром <code className="font-mono text-brass-light">?role=display</code>.
              </p>
              <Toggle label="Включить трансляцию на табло" on={r.enabled} onChange={(v) => setRemote({ enabled: v })} />
              <Field label="Адрес сервера" hint="Пусто = тот же адрес, откуда открыто приложение.">
                <input
                  value={r.url}
                  onChange={(e) => setRemote({ url: e.target.value })}
                  placeholder="http://192.168.0.10:8787"
                  className="w-72 rounded-md border-2 border-brass-dark bg-[#1a0f08] px-3 py-2 font-mono text-[1rem] text-brass-light"
                />
              </Field>
              <Field label="Токен (если задан на сервере)">
                <input
                  value={r.token}
                  onChange={(e) => setRemote({ token: e.target.value })}
                  className="w-72 rounded-md border-2 border-brass-dark bg-[#1a0f08] px-3 py-2 font-mono text-[1rem] text-brass-light"
                />
              </Field>
              {FEATURES.remoteVideo && (
                <Toggle label="Передавать и видео (сжатое)" on={r.sendVideo} onChange={(v) => setRemote({ sendVideo: v })} />
              )}
              <div className="text-[0.95rem] text-[#b9a27a]">
                Связь: {remoteStatus === "ok" ? "✔ установлена" : remoteStatus === "error" ? "✖ нет связи" : "выключено"}
              </div>
            </div>
          )}
        </div>
        <p className="mt-3 text-center text-[0.9rem] text-[#a38d66]">
          Всё распознавание выполняется локально в браузере. Видео не покидает компьютер.
        </p>
      </div>
    </div>
  );
}
