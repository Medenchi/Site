import type { CamStatus } from "../hooks/useCamera";

interface Props {
  status: CamStatus;
  error: string | null;
  onStart: () => void;
}

/** Экран включения камеры / ошибок доступа. */
export function CameraGate({ status, error, onStart }: Props) {
  const busy = status === "starting";
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/55 p-8 backdrop-blur-[2px]">
      <div className="iron rivets animate-fadein flex max-w-[44rem] flex-col items-center gap-5 px-12 py-10 text-center">
        <div className="font-display text-[2.6rem] tracking-wider text-brass-light engrave">
          {status === "error" ? "КАМЕРА НЕДОСТУПНА" : "КАМЕРА ВЫКЛЮЧЕНА"}
        </div>
        {error ? (
          <p className="rounded-md border border-[#7a2a20] bg-[#2a0d09] px-5 py-3 text-[1.25rem] leading-snug text-[#ffb3a8]">
            {error}
          </p>
        ) : (
          <p className="text-[1.3rem] leading-snug text-[#d8c39a]">
            Приложение найдёт всех учеников в кадре и закрепит за каждым отдельную рамку.
            <br />
            Видео обрабатывается только в этом браузере и никуда не отправляется.
          </p>
        )}
        <button className="btn btn-gold !min-h-[5rem] !px-10 !text-[1.9rem]" disabled={busy} onClick={onStart}>
          {busy ? "Запуск…" : status === "error" ? "↻ Повторить" : "● Включить камеру"}
        </button>
        <p className="text-[0.95rem] text-[#a38d66]">
          Совет: для ручной разметки рамок достаточно включить камеру — модели ИИ загрузятся автоматически.
        </p>
      </div>
    </div>
  );
}
