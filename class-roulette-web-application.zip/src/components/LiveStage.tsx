import { ReactNode, RefObject, useRef } from "react";
import { FEATURES } from "../config";
import type { BoxEditor, Tool } from "../lib/editor";
import type { Game } from "../lib/game";
import type { RemoteHost } from "../lib/remote";
import type { RemoteState } from "../lib/types";
import { StageSurface } from "./StageSurface";

interface Props {
  game: Game;
  editor: BoxEditor;
  tool: Tool;
  videoRef: RefObject<HTMLVideoElement | null>;
  size: { w: number; h: number } | null;
  live: boolean;
  remote: RemoteHost | null;
  overlay?: ReactNode;
}

/** Живая сцена: видео с камеры + canvas с хитбоксами. */
export function LiveStage({ game, editor, tool, videoRef, size, live, remote, overlay }: Props) {
  const aspect = size ? size.w / size.h : 16 / 9;
  const lastPhase = useRef(game.phase);

  const onFrame = (dt: number, now: number) => {
    game.step(dt, now);
    if (FEATURES.remote && remote) {
      const force = lastPhase.current !== game.phase;
      lastPhase.current = game.phase;
      const snap = game.getSnapshot();
      const state: RemoteState = {
        v: 1,
        ts: Date.now(),
        aspect,
        hasVideo: live,
        model: game.toModel(now, false),
        snapshot: {
          participants: snap.participants,
          phase: snap.phase,
          winnerId: snap.winnerId,
          selectedId: null,
          history: snap.history.slice(0, 30),
          round: snap.round,
          eligible: snap.eligible,
          total: snap.total,
        },
      };
      remote.push(state, videoRef.current, now, force);
    }
  };

  return (
    <StageSurface
      aspect={aspect}
      cursor={tool === "add" ? "crosshair" : "default"}
      getModel={(now) => game.toModel(now, live && !game.busy)}
      onFrame={onFrame}
      onPointer={(type, p) => {
        if (!live) return false;
        editor.tool = tool;
        if (type === "down") return editor.down(p);
        if (!editor.dragging) return false;
        if (type === "move") editor.move(p);
        else if (type === "up") editor.up(p);
        else editor.cancel();
        return false;
      }}
      overlay={overlay}
    >
      <video
        ref={videoRef}
        className="absolute inset-0 h-full w-full"
        style={{ transform: game.mirror ? "scaleX(-1)" : undefined, opacity: live ? 1 : 0 }}
        playsInline
        muted
        autoPlay
      />
      {!live && (
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(rgba(217,178,106,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(217,178,106,0.06) 1px, transparent 1px)",
            backgroundSize: "4rem 4rem",
          }}
        />
      )}
    </StageSurface>
  );
}
