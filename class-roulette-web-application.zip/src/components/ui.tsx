import { ReactNode } from "react";

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className="flex min-h-[3rem] w-full items-center justify-between gap-4 rounded-md px-1 text-left"
      aria-pressed={on}
    >
      <span className="text-[1.15rem] tracking-wide text-[#ecd9b4]">{label}</span>
      <span
        className="relative h-[1.9rem] w-[3.6rem] shrink-0 rounded-full border-2 border-brass-dark transition-colors"
        style={{ background: on ? "linear-gradient(180deg,#b88a38,#e8c26a)" : "#1a0f08" }}
      >
        <span
          className="absolute top-[0.1rem] h-[1.4rem] w-[1.4rem] rounded-full bg-[#2a170c] shadow transition-all"
          style={{ left: on ? "1.8rem" : "0.15rem", border: "2px solid #f6dc9a" }}
        />
      </span>
    </button>
  );
}

export function Segmented<T extends string | number>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="inline-flex overflow-hidden rounded-md border-2 border-brass-dark">
      {options.map((o) => (
        <button
          key={String(o.value)}
          type="button"
          onClick={() => onChange(o.value)}
          className="min-h-[2.7rem] px-4 text-[1.05rem] font-semibold uppercase tracking-wider"
          style={{
            background: o.value === value ? "linear-gradient(180deg,#e8c26a,#b88a38)" : "#1a0f08",
            color: o.value === value ? "#2a170c" : "#d9b26a",
          }}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1 py-2">
      <div className="flex items-center justify-between gap-4">
        <span className="text-[1.15rem] tracking-wide text-[#ecd9b4]">{label}</span>
        {children}
      </div>
      {hint && <span className="text-[0.9rem] leading-snug text-[#b9a27a]">{hint}</span>}
    </div>
  );
}

export const fmtTime = (t: number) =>
  new Date(t).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
