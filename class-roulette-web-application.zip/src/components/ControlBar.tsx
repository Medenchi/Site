import type { Snapshot } from "../lib/types";

interface Props {
  snap: Snapshot;
  calibrating: boolean;
  live: boolean;
  durationSec: number;
  onDuration: (s: number) => void;
  onSpin: () => void;
  onReset: () => void;
}

export function ControlBar({ snap, calibrating, live, durationSec, onDuration, onSpin, onReset }: Props) {
  const busy = snap.phase === "spinning" || snap.phase === "tension";
  let disabled = false;
  let sub = `в игре: ${snap.eligible} из ${snap.total}`;
  if (busy) {
    disabled = true;
    sub = "идёт розыгрыш…";
  } else if (!live && snap.total === 0) {
    disabled = true;
    sub = "включите камеру";
  } else if (calibrating) {
    disabled = true;
    sub = "завершите калибровку";
  } else if (snap.total === 0) {
    disabled = true;
    sub = "нет участников";
  } else if (snap.eligible === 0) {
    disabled = true;
    sub = "все выбраны — нажмите «Сбросить»";
  } else if (snap.phase === "reveal") {
    sub = `ещё раз · в игре: ${snap.eligible}`;
  }

  return (
    <div className="flex h-[10.5rem] shrink-0 items-stretch gap-6 px-2 pb-6 pt-1">
      <button className="btn btn-danger !h-full !w-[13rem] shrink-0 flex-col !gap-1 !text-[1.5rem]" onClick={onReset}>
        <span className="text-[2rem] leading-none">↺</span>
        Сбросить
      </button>

      <div className="min-w-0 flex-1 px-3 pb-3">
        <button className="spin-btn flex flex-col items-center justify-center" disabled={disabled} onClick={onSpin}>
          <span className="leading-none">{snap.phase === "reveal" ? "КРУТИТЬ ЕЩЁ" : "КРУТИТЬ"}</span>
          <span
            className="mt-2 font-ui text-[1.2rem] font-medium uppercase tracking-[0.25em] text-[#ffd9c9]"
            style={{ textShadow: "none" }}
          >
            {sub}
          </span>
        </button>
      </div>

      <div className="iron flex w-[15rem] shrink-0 flex-col items-center justify-center gap-1 px-2">
        <div className="text-[0.9rem] uppercase tracking-[0.2em] text-[#b9a27a]">длительность</div>
        <div className="flex items-center gap-2">
          <button className="btn btn-icon !min-w-[3.4rem] !text-[1.8rem]" disabled={busy || durationSec <= 3} onClick={() => onDuration(durationSec - 1)}>
            −
          </button>
          <div className="w-[4.6rem] text-center font-display text-[2.2rem] leading-none text-brass-light tabular-nums">
            {durationSec}
            <span className="ml-0.5 text-[1.1rem]">с</span>
          </div>
          <button className="btn btn-icon !min-w-[3.4rem] !text-[1.8rem]" disabled={busy || durationSec >= 20} onClick={() => onDuration(durationSec + 1)}>
            +
          </button>
        </div>
      </div>
    </div>
  );
}
