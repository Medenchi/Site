import type { Game } from "../lib/game";
import type { Snapshot } from "../lib/types";
import { fmtTime } from "./ui";

const STATE_LABEL: Record<string, string> = {
  tracked: "в кадре",
  held: "закрыт / не виден",
  tentative: "…",
};

export function ParticipantsCard({ snap, game }: { snap: Snapshot; game: Game }) {
  const busy = snap.phase === "spinning" || snap.phase === "tension";
  return (
    <section className="wood-panel flex min-h-0 flex-[3] flex-col p-3">
      <div className="mb-2 flex items-center justify-between gap-2 px-1">
        <h2 className="font-display text-[1.5rem] tracking-wider text-brass-light engrave">УЧАСТНИКИ</h2>
        <button className="btn btn-sm" disabled={busy} onClick={() => game.addManual()}>
          ＋ Добавить
        </button>
      </div>
      <div className="iron scroll-wood min-h-0 flex-1 overflow-y-auto p-2">
        {snap.participants.length === 0 ? (
          <div className="px-4 py-8 text-center text-[1.2rem] leading-snug text-[#a38d66]">
            Пока никого нет.
            <br />
            Встаньте перед камерой — рамки появятся сами, либо добавьте вручную.
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {snap.participants.map((p) => {
              const selected = p.id === snap.selectedId;
              const isWinner = p.id === snap.winnerId && snap.phase === "reveal";
              return (
                <li
                  key={p.id}
                  onClick={() => game.select(selected ? null : p.id)}
                  className="flex min-h-[3.6rem] cursor-pointer items-center gap-3 rounded-md border-2 px-2 py-1.5"
                  style={{
                    borderColor: isWinner ? "#ff3a2c" : selected ? "#f6dc9a" : "#3a2814",
                    background: isWinner ? "rgba(224,34,26,0.3)" : selected ? "rgba(217,178,106,0.14)" : "rgba(0,0,0,0.25)",
                    opacity: p.excluded && !isWinner ? 0.6 : 1,
                  }}
                >
                  <span
                    className="font-display flex h-[2.6rem] min-w-[4rem] items-center justify-center rounded border-2 px-2 text-[1.35rem]"
                    style={{
                      borderColor: p.excluded ? "#6e655c" : "#d9b26a",
                      color: p.excluded ? "#a89c8e" : "#f6dc9a",
                      background: "#2a170c",
                    }}
                  >
                    №{p.num}
                  </span>
                  <div className="min-w-0 flex-1 leading-tight">
                    <div className="truncate text-[1.1rem] text-[#ecd9b4]">
                      {p.excluded ? "выбыл из игры" : STATE_LABEL[p.state]}
                    </div>
                    <div className="text-[0.85rem] uppercase tracking-wider text-[#a38d66]">
                      {p.manual ? "вручную" : "авто"}
                      {p.locked && !p.manual ? " · закреплён" : ""}
                    </div>
                  </div>
                  <button
                    className="btn btn-sm !px-3"
                    disabled={busy}
                    onClick={(e) => {
                      e.stopPropagation();
                      game.setExcluded(p.id, !p.excluded);
                    }}
                  >
                    {p.excluded ? "Вернуть" : "Исключить"}
                  </button>
                  <button
                    className="btn btn-sm btn-danger btn-icon !min-w-[2.6rem] !px-2"
                    disabled={busy}
                    title="Удалить"
                    onClick={(e) => {
                      e.stopPropagation();
                      game.removeParticipant(p.id);
                    }}
                  >
                    ✕
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}

export function HistoryCard({
  history,
  onClear,
}: {
  history: Snapshot["history"];
  onClear?: () => void;
}) {
  return (
    <section className="wood-panel flex min-h-0 flex-[2] flex-col p-3">
      <div className="mb-2 flex items-center justify-between px-1">
        <h2 className="font-display text-[1.5rem] tracking-wider text-brass-light engrave">ИСТОРИЯ</h2>
        {onClear && (
          <button className="btn btn-sm" disabled={history.length === 0} onClick={onClear}>
            Очистить
          </button>
        )}
      </div>
      <div className="iron scroll-wood min-h-0 flex-1 overflow-y-auto p-2">
        {history.length === 0 ? (
          <div className="px-4 py-6 text-center text-[1.15rem] text-[#a38d66]">Выборов ещё не было</div>
        ) : (
          <ul className="flex flex-col gap-1.5">
            {history.map((h, i) => (
              <li
                key={`${h.round}-${h.id}-${h.at}`}
                className="flex items-center gap-3 rounded-md px-3 py-1.5"
                style={{
                  background: i === 0 ? "rgba(224,34,26,0.22)" : "rgba(0,0,0,0.25)",
                  border: `2px solid ${i === 0 ? "#b03a2e" : "#3a2814"}`,
                }}
              >
                <span className="w-[4.2rem] text-[0.95rem] uppercase tracking-wider text-[#a38d66]">р. {h.round}</span>
                <span className="font-display text-[1.6rem] text-brass-light">№{h.num}</span>
                <span className="ml-auto text-right font-mono text-[0.9rem] text-[#b9a27a]">
                  {fmtTime(h.at)}
                  <br />
                  <span className="text-[0.75rem] text-[#8a7650]">из {h.pool}</span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
