#!/usr/bin/env node
/**
 * Необязательный сервер для «серверного режима» CLASS ROULETTE.
 *
 *   node server/server.mjs
 *
 * Что делает:
 *   • раздаёт собранное приложение из ./dist
 *   • POST /api/state  — принимает состояние игры от устройства с камерой
 *   • GET  /api/events — Server-Sent Events: рассылает состояние всем табло
 *   • POST/GET /api/frame — (опционально) последний сжатый кадр с камеры
 *
 * Видео НЕ хранится на диске: последний кадр держится только в памяти и
 * только если на хосте включена опция «Передавать и видео».
 *
 * Переменные окружения:
 *   PORT=8787          порт
 *   HOST=0.0.0.0       интерфейс
 *   REMOTE_TOKEN=xxx   общий токен (если задан — обязателен у хоста и табло)
 *
 * Зависимостей нет — только стандартная библиотека Node.js (>= 18).
 */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.resolve(__dirname, "../dist");
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || "0.0.0.0";
const TOKEN = process.env.REMOTE_TOKEN || "";
const MAX_BODY = 4 * 1024 * 1024;

/** @type {string | null} */
let lastState = null;
/** @type {Buffer | null} */
let lastFrame = null;
/** @type {Set<http.ServerResponse>} */
const clients = new Set();

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".wasm": "application/wasm",
  ".tflite": "application/octet-stream",
  ".task": "application/octet-stream",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".woff2": "font/woff2",
  ".ico": "image/x-icon",
};

function cors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "content-type, x-token");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
}

function authed(req, url) {
  if (!TOKEN) return true;
  return req.headers["x-token"] === TOKEN || url.searchParams.get("token") === TOKEN;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new Error("too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function broadcast(json) {
  const msg = `event: state\ndata: ${json}\n\n`;
  for (const c of clients) c.write(msg);
}

function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname);
  if (rel.endsWith("/")) rel += "index.html";
  const file = path.normalize(path.join(DIST, rel));
  if (!file.startsWith(DIST)) {
    res.writeHead(403).end("Forbidden");
    return;
  }
  fs.stat(file, (err, st) => {
    const target = !err && st.isFile() ? file : path.join(DIST, "index.html");
    fs.readFile(target, (e, data) => {
      if (e) {
        res.writeHead(404).end("Not found. Сначала выполните: npm run build");
        return;
      }
      res.writeHead(200, {
        "Content-Type": MIME[path.extname(target).toLowerCase()] || "application/octet-stream",
        "Cache-Control": target.endsWith("index.html") ? "no-cache" : "public, max-age=3600",
      });
      res.end(data);
    });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
  cors(res);
  if (req.method === "OPTIONS") {
    res.writeHead(204).end();
    return;
  }

  if (url.pathname === "/api/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true, displays: clients.size, hasState: lastState !== null }));
    return;
  }

  if (url.pathname.startsWith("/api/")) {
    if (!authed(req, url)) {
      res.writeHead(401).end("unauthorized");
      return;
    }

    if (url.pathname === "/api/state" && req.method === "POST") {
      try {
        const body = (await readBody(req)).toString("utf8");
        JSON.parse(body); // проверка корректности
        lastState = body.replace(/[\r\n]+/g, " ");
        broadcast(lastState);
        res.writeHead(204).end();
      } catch {
        res.writeHead(400).end("bad request");
      }
      return;
    }

    if (url.pathname === "/api/frame" && req.method === "POST") {
      try {
        lastFrame = await readBody(req);
        res.writeHead(204).end();
      } catch {
        res.writeHead(400).end("bad request");
      }
      return;
    }

    if (url.pathname === "/api/frame" && req.method === "GET") {
      if (!lastFrame) {
        res.writeHead(404).end();
        return;
      }
      res.writeHead(200, { "Content-Type": "image/jpeg", "Cache-Control": "no-store" });
      res.end(lastFrame);
      return;
    }

    if (url.pathname === "/api/events" && req.method === "GET") {
      res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
      });
      res.write("retry: 1500\n\n");
      if (lastState) res.write(`event: state\ndata: ${lastState}\n\n`);
      clients.add(res);
      const hb = setInterval(() => res.write(": ping\n\n"), 15000);
      req.on("close", () => {
        clearInterval(hb);
        clients.delete(res);
      });
      return;
    }

    res.writeHead(404).end("not found");
    return;
  }

  serveStatic(req, res, url);
});

server.listen(PORT, HOST, () => {
  console.log(`CLASS ROULETTE server: http://localhost:${PORT}`);
  console.log(`  Хост (камера):   http://localhost:${PORT}/`);
  console.log(`  Табло на доске:  http://<IP-этого-компьютера>:${PORT}/?role=display`);
  if (TOKEN) console.log("  Токен включён: добавьте &token=... к адресу табло");
  if (!fs.existsSync(DIST)) console.log("  ⚠ Папка dist не найдена — выполните npm run build");
});
